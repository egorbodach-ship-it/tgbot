#!/usr/bin/env python3
"""
Bulk-patches menu_title in all DeluxeMenus YAMLs.

Reads codepoints from the latest pack's default.json (so it
auto-recovers if Oraxen reshuffled), then rewrites each YAML's
menu_title line to the single Tamil codepoint that maps to that
menu's overlay PNG.

Usage:
    PTERODACTYL_KEY=... python3 bulk_patch_titles.py

Verifies size and HTTP status of each upload; aborts on the first failure.
"""

from __future__ import annotations
import os, re, sys, json, urllib.parse, subprocess
from io import BytesIO
from zipfile import ZipFile

KEY  = os.environ['PTERODACTYL_KEY']
BASE = 'https://mgr.hosting-minecraft.pro/api/client/servers/944c2567'

# DM config menu_key -> YAML path -> glyph_name (PNG basename)
ASSIGN: list[tuple[str, str, str]] = [
    # menu_key,         yaml_path,                            glyph
    ("menu",            "menu/menu.yml",                      "menu"),
    ("donate",          "menu/donate.yml",                    "donate"),
    ("help",            "menu/help.yml",                      "help"),
    ("panel",           "menu/panel.yml",                     "panel"),
    ("grab",            "menu/grab.yml",                      "grab"),
    ("freek",           "menu/freek.yml",                     "freek"),
    ("media",           "menu/media.yml",                     "media"),
    ("obmen",           "menu/obmen.yml",                     "obmen"),
    ("rtp",             "menu/rtp.yml",                       "rtp"),
    ("arenda",          "menu/arenda.yml",                    "arenda"),
    ("event",           "menu/events.yml",                    "events"),
    ("egorchik",        "menu/egorchik.yml",                  "egorchik"),
    ("portals",         "menu/portals.yml",                   "portals"),
    ("akriwer",         "menu/akriwer.yml",                   "akriwer"),
    ("akriwer1",        "menu/akriwer1.yml",                  "akriwer"),
    ("akriwer2",        "menu/akriwer2.yml",                  "akriwer"),
    ("donateSHOP",      "shop/donateSHOP.yml",                "shop"),
    ("donateSHARI",     "shop/donateSHARI.yml",               "shari"),
    ("donateARROW",     "shop/donateARROW.yml",               "arrow"),
    ("donatePOTIONS",   "shop/donatePOTIONS.yml",             "potions"),
    ("donateRESMENU",   "shop/donateRESMENU.yml",             "resmenu"),
    ("donateRESEURO",   "shop/donateRESEURO.yml",             "reseuro"),
    ("donateRESMONETA", "shop/donateRESMONETA.yml",           "resmoneta"),
    ("donateEGG",       "shop/donateEGG.yml",                 "egg"),
    ("donateITEMS2",    "shop/donateITEMS2.yml",              "items"),
    ("donateSPAWNERS",  "shop/donateSPAWNERS.yml",            "spawners"),
    ("donateLIVALKA",   "shop/donateLIVALKA.yml",             "livalka"),
    ("donatePRED",      "shop/donatePRED.yml",                "pred"),
    ("donatePVE",       "shop/donatePVE.yml",                 "pve"),
    ("donatePVEOTHER",  "shop/donatePVEOTHER.yml",            "pveother"),
]


def read_current_pack_url() -> str:
    """Fetch /server.properties and extract the resource-pack= URL."""
    enc = urllib.parse.quote('/server.properties')
    r = subprocess.run(['curl', '-sf',
                        '-H', f'Authorization: Bearer {KEY}',
                        f'{BASE}/files/contents?file={enc}'],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit('failed to read server.properties')
    for line in r.stdout.splitlines():
        if line.startswith('resource-pack='):
            return line.split('=', 1)[1].replace('\\:', ':').replace('\\=', '=')
    sys.exit('no resource-pack= in server.properties')


def fetch_default_json(pack_url: str) -> dict:
    """Download the live pack zip and return default.json's parsed contents."""
    r = subprocess.run(['curl', '-s', pack_url, '-o', '/tmp/_pack_for_codepoints.zip'])
    if r.returncode != 0:
        sys.exit('failed to download pack zip')
    with ZipFile('/tmp/_pack_for_codepoints.zip') as z:
        with z.open('assets/minecraft/font/default.json') as f:
            return json.load(f)


def build_glyph_to_codepoint(default_json: dict) -> dict[str, int]:
    """
    Build {glyph_name -> codepoint} for every provider whose file is
    'font/menus/<name>.png'. Returns the FIRST char.
    """
    out: dict[str, int] = {}
    for p in default_json.get('providers', []):
        fn = p.get('file', '')
        if not fn.startswith('font/menus/'):
            continue
        name = fn[len('font/menus/'):].rsplit('.', 1)[0]
        chars = p.get('chars') or []
        if chars and chars[0]:
            out[name] = ord(chars[0][0])
    return out


_TITLE_RE = re.compile(rb'^menu_title:\s.*$', re.MULTILINE)


def fetch_yaml(yaml_rel: str) -> bytes:
    enc = urllib.parse.quote(f'/plugins/DeluxeMenus/gui_menus/{yaml_rel}')
    r = subprocess.run(['curl', '-sf',
                        '-H', f'Authorization: Bearer {KEY}',
                        f'{BASE}/files/contents?file={enc}'],
                       capture_output=True)
    if r.returncode != 0:
        sys.exit(f'failed to read {yaml_rel}')
    return r.stdout


def write_yaml(yaml_rel: str, body: bytes) -> str:
    enc = urllib.parse.quote(f'/plugins/DeluxeMenus/gui_menus/{yaml_rel}')
    tmp = f'/tmp/_yaml_{yaml_rel.replace("/", "__")}'
    with open(tmp, 'wb') as f:
        f.write(body)
    r = subprocess.run([
        'curl', '-sf', '-X', 'POST',
        '-H', f'Authorization: Bearer {KEY}',
        '-H', 'Content-Type: application/octet-stream',
        '--data-binary', f'@{tmp}',
        f'{BASE}/files/write?file={enc}',
        '-w', '%{http_code}',
    ], capture_output=True, text=True)
    return r.stdout.strip()


def dm_reload() -> None:
    subprocess.run([
        'curl', '-s', '-X', 'POST',
        '-H', f'Authorization: Bearer {KEY}',
        '-H', 'Content-Type: application/json',
        '-d', '{"command":"dm reload"}',
        f'{BASE}/command',
    ], capture_output=True)


def main():
    pack_url = read_current_pack_url()
    print(f'pack URL  : {pack_url}')
    dj = fetch_default_json(pack_url)
    m  = build_glyph_to_codepoint(dj)
    if len(m) < 28:
        sys.exit(f'expected 28 font/menus glyphs in default.json, got {len(m)}')
    print(f'glyphs    : {len(m)} known')
    print()

    ok = 0
    for key, yaml_rel, glyph in ASSIGN:
        cp = m.get(glyph)
        if cp is None:
            print(f'  SKIP {yaml_rel}: glyph "{glyph}" not in default.json')
            continue
        body = fetch_yaml(yaml_rel)
        new_title = f'menu_title: "{chr(cp)}"'.encode('utf-8')
        new_body, n = _TITLE_RE.subn(new_title, body, count=1)
        if n != 1:
            print(f'  SKIP {yaml_rel}: no menu_title: line')
            continue
        if new_body == body:
            print(f'  same  {yaml_rel:30s}  (already U+{cp:04X})')
            ok += 1
            continue
        code = write_yaml(yaml_rel, new_body)
        status = 'OK' if code == '204' else f'FAIL({code})'
        print(f'  {status:7s} {yaml_rel:30s} -> U+{cp:04X}  ({glyph})')
        if code == '204':
            ok += 1

    print()
    print(f'patched: {ok}/{len(ASSIGN)}')
    print('reloading DeluxeMenus...')
    dm_reload()


if __name__ == '__main__':
    main()
