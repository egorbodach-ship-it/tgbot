#!/usr/bin/env python3
"""Generate orange-black GUI container textures for Grief Server.

Produces 256x256 PNGs in the same layout vanilla Minecraft 1.16.5 expects:
- gui/container/generic_54.png  (chest 1-6 rows + player inv panel)
- gui/container/inventory.png   (player inventory screen)
- gui/container/hopper.png      (1x5 hopper)
- gui/container/dispenser.png   (3x3 dispenser/dropper)
- gui/container/shulker_box.png (3x9 shulker)

Style: matches existing banner glyphs (#FF5700 orange + #0F0F0F black,
sharp diagonal wedges, thin orange hairlines).
"""

import os
from PIL import Image, ImageDraw

PACK_DIR = "/home/ubuntu/work/new_pack"
OUT_DIR = os.path.join(PACK_DIR, "assets/minecraft/textures/gui/container")
os.makedirs(OUT_DIR, exist_ok=True)

# Palette
ORANGE = (255, 87, 0, 255)
ORANGE_HI = (255, 138, 64, 255)
ORANGE_DK = (160, 50, 0, 255)
BLACK = (15, 15, 15, 255)
PANEL = (28, 28, 28, 255)
PANEL_HI = (44, 44, 44, 255)
PANEL_LO = (18, 18, 18, 255)
SLOT_BG = (6, 6, 6, 255)
SLOT_SHADOW = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
TRANS = (0, 0, 0, 0)

W_TEX = 256
H_TEX = 256
W_GUI = 176  # canonical container width


def draw_panel_frame(draw: ImageDraw.ImageDraw, x: int, y: int, w: int, h: int):
    """Outer panel: dark fill, two-tone orange border, sharp wedge accents."""
    # Solid dark fill (panel body)
    draw.rectangle([x, y, x + w - 1, y + h - 1], fill=PANEL)
    # Inner 1px highlight (subtle)
    draw.rectangle([x + 1, y + 1, x + w - 2, y + h - 2], outline=PANEL_HI)
    # Inner body fill
    draw.rectangle([x + 2, y + 2, x + w - 3, y + h - 3], fill=PANEL)
    # 2px outer orange frame (top/bottom/left/right thick)
    draw.rectangle([x, y, x + w - 1, y + h - 1], outline=ORANGE)
    # 1px darker outer outline (gives weight)
    draw.rectangle([x, y, x + w - 1, y + h - 1], outline=ORANGE_DK)
    draw.rectangle([x + 1, y + 1, x + w - 2, y + h - 2], outline=ORANGE)


def draw_slot(img: Image.Image, x: int, y: int):
    """One 18x18 item slot — recessed dark square with subtle bevel.

    Layout (vanilla-style inset, just re-tinted):
      ┌──────────────────┐      x+0 row  : top shadow #2a2a2a
      │░░░░░░░░░░░░░░░░░░│      x+1..16  : 16x16 inner = #060606 fill
      │░     16×16     ▓│
      │░                ▓│      x+17 row : bottom highlight #3d3d3d
      └──────────────────┘
    """
    inner_fill = SLOT_BG
    shadow = (24, 24, 24, 255)
    highlight = (58, 58, 58, 255)
    # Fill all 18x18 with inner first
    for j in range(18):
        for i in range(18):
            img.putpixel((x + i, y + j), inner_fill)
    # Top edge + left edge = shadow
    for i in range(18):
        img.putpixel((x + i, y), shadow)
    for j in range(18):
        img.putpixel((x, y + j), shadow)
    # Bottom edge + right edge = highlight
    for i in range(18):
        img.putpixel((x + i, y + 17), highlight)
    for j in range(18):
        img.putpixel((x + 17, y + j), highlight)
    # Tiny orange pip in top-left corner only — subtle brand mark
    img.putpixel((x + 1, y + 1), ORANGE_DK)


def draw_slot_row(img: Image.Image, x0: int, y0: int, cols: int):
    for c in range(cols):
        draw_slot(img, x0 + c * 18, y0)


def draw_diag_wedge(draw: ImageDraw.ImageDraw, x: int, y: int, size: int, side: str):
    """Diagonal orange wedge accent for corners (mirrors banner style)."""
    if side == "tl":
        pts = [(x, y), (x + size, y), (x, y + size)]
    elif side == "tr":
        pts = [(x, y), (x + size, y), (x + size, y + size)]
    elif side == "bl":
        pts = [(x, y + size), (x, y), (x + size, y + size)]
    else:  # br
        pts = [(x + size, y), (x + size, y + size), (x, y + size)]
    draw.polygon(pts, fill=ORANGE)


def draw_title_bar(img: Image.Image, x0: int, y0: int, w: int, h: int):
    """Top title strip — slightly lighter panel + sharp orange chevrons either side."""
    draw = ImageDraw.Draw(img)
    # Title strip fill (slightly lighter than panel)
    draw.rectangle([x0 + 3, y0 + 3, x0 + w - 4, y0 + h - 1], fill=PANEL_HI)
    # Orange hairline at the bottom of the title bar
    draw.line([(x0 + 3, y0 + h - 1), (x0 + w - 4, y0 + h - 1)], fill=ORANGE)
    # Wedge accents
    # Left wedge (orange triangle pointing right)
    wedge_w = 14
    pts_l = [(x0 + 3, y0 + 3), (x0 + 3 + wedge_w, y0 + 3),
             (x0 + 3, y0 + h - 2)]
    draw.polygon(pts_l, fill=ORANGE)
    # mirror right
    pts_r = [(x0 + w - 4, y0 + 3), (x0 + w - 4 - wedge_w, y0 + 3),
             (x0 + w - 4, y0 + h - 2)]
    draw.polygon(pts_r, fill=ORANGE)


def draw_separator(draw: ImageDraw.ImageDraw, x0: int, y0: int, w: int):
    """Thin orange separator stripe between chest slots and player inventory."""
    # bg fill (panel)
    draw.rectangle([x0 + 3, y0, x0 + w - 4, y0 + 3], fill=PANEL)
    # single bold orange line
    draw.line([(x0 + 6, y0 + 1), (x0 + w - 7, y0 + 1)], fill=ORANGE)
    # darker hairline below for depth
    draw.line([(x0 + 6, y0 + 2), (x0 + w - 7, y0 + 2)], fill=ORANGE_DK)


def render_chest():
    """generic_54.png — 256x256, chest container layout."""
    img = Image.new("RGBA", (W_TEX, H_TEX), TRANS)
    draw = ImageDraw.Draw(img)
    # ── Top portion (rows 0..125): title bar + 6 slot rows
    # Outer panel goes from (0,0) to (176, ~222). Vertical layout:
    #   y=0..16  : title bar    (17 px)
    #   y=17..124: 6 rows × 18  (108 px)
    #   y=125    : closing edge (1 px)
    # Then bottom panel from y=126..221 (96 px): separator + inv label area + 3 inv rows + hotbar
    PANEL_W = W_GUI
    PANEL_H_TOP = 17 + 6 * 18  # 125
    # Top panel
    draw_panel_frame(draw, 0, 0, PANEL_W, PANEL_H_TOP)
    draw_title_bar(img, 0, 0, PANEL_W, 17)
    # 6 slot rows starting at (8, 18)
    for r in range(6):
        draw_slot_row(img, 8, 18 + r * 18, 9)
    # close top panel with orange hairline
    draw.line([(2, PANEL_H_TOP - 1), (PANEL_W - 3, PANEL_H_TOP - 1)], fill=ORANGE)

    # ── Bottom portion (rows 126..221): player inventory + hotbar
    BOT_Y = 126
    BOT_H = 96
    draw_panel_frame(draw, 0, BOT_Y, PANEL_W, BOT_H)
    # decorative separator near the very top of bottom panel
    draw_separator(draw, 0, BOT_Y + 0, PANEL_W)
    # 3 rows of player inv slots starting at (8, BOT_Y + 14)
    inv_y0 = BOT_Y + 13
    for r in range(3):
        draw_slot_row(img, 8, inv_y0 + r * 18, 9)
    # Hotbar slots — 4px gap below inventory
    hotbar_y = inv_y0 + 3 * 18 + 4
    draw_slot_row(img, 8, hotbar_y, 9)
    # close bottom panel hairline at the very bottom
    draw.line([(2, BOT_Y + BOT_H - 1), (PANEL_W - 3, BOT_Y + BOT_H - 1)], fill=ORANGE)
    # subtle orange under-hotbar accent
    draw.line([(8, hotbar_y + 18 + 1), (8 + 9 * 18 - 1, hotbar_y + 18 + 1)],
              fill=ORANGE_DK)

    out = os.path.join(OUT_DIR, "generic_54.png")
    img.save(out)
    print(f"wrote {out}  ({img.size[0]}x{img.size[1]})")


def render_inventory():
    """inventory.png — player inventory screen (E key), 176x166."""
    img = Image.new("RGBA", (W_TEX, H_TEX), TRANS)
    draw = ImageDraw.Draw(img)
    PANEL_W = W_GUI
    PANEL_H = 166
    draw_panel_frame(draw, 0, 0, PANEL_W, PANEL_H)
    draw_title_bar(img, 0, 0, PANEL_W, 17)
    # crafting 2x2 at (98, 18) and result slot at (154, 28) — keep vanilla geometry
    for r in range(2):
        for c in range(2):
            draw_slot(img, 98 + c * 18, 18 + r * 18)
    draw_slot(img, 154, 28)
    # Armor slots 1x4 at (8, 8..62) + offhand at (77, 62)
    for r in range(4):
        draw_slot(img, 8, 8 + r * 18)
    draw_slot(img, 77, 62)
    # 3 rows of inv slots starting at (8, 84)
    inv_y0 = 84
    for r in range(3):
        draw_slot_row(img, 8, inv_y0 + r * 18, 9)
    hotbar_y = inv_y0 + 3 * 18 + 4
    draw_slot_row(img, 8, hotbar_y, 9)
    # accent line
    draw.line([(2, PANEL_H - 1), (PANEL_W - 3, PANEL_H - 1)], fill=ORANGE)

    out = os.path.join(OUT_DIR, "inventory.png")
    img.save(out)
    print(f"wrote {out}  ({img.size[0]}x{img.size[1]})")


def render_hopper():
    """hopper.png — 176x133, 1 row × 5 slots."""
    img = Image.new("RGBA", (W_TEX, H_TEX), TRANS)
    draw = ImageDraw.Draw(img)
    PANEL_W = W_GUI
    PANEL_H = 133
    draw_panel_frame(draw, 0, 0, PANEL_W, PANEL_H)
    draw_title_bar(img, 0, 0, PANEL_W, 17)
    # 5 hopper slots at (44..116, 19)
    for c in range(5):
        draw_slot(img, 44 + c * 18, 19)
    # Player inv at (7, 50)
    inv_y0 = 50
    for r in range(3):
        draw_slot_row(img, 7, inv_y0 + r * 18, 9)
    hotbar_y = inv_y0 + 3 * 18 + 4
    draw_slot_row(img, 7, hotbar_y, 9)
    draw.line([(2, PANEL_H - 1), (PANEL_W - 3, PANEL_H - 1)], fill=ORANGE)
    out = os.path.join(OUT_DIR, "hopper.png")
    img.save(out)
    print(f"wrote {out}  ({img.size[0]}x{img.size[1]})")


def render_dispenser():
    """dispenser.png — 176x166, 3x3 grid."""
    img = Image.new("RGBA", (W_TEX, H_TEX), TRANS)
    draw = ImageDraw.Draw(img)
    PANEL_W = W_GUI
    PANEL_H = 166
    draw_panel_frame(draw, 0, 0, PANEL_W, PANEL_H)
    draw_title_bar(img, 0, 0, PANEL_W, 17)
    # 3x3 grid at (62, 17) (vanilla offset)
    for r in range(3):
        for c in range(3):
            draw_slot(img, 62 + c * 18, 17 + r * 18)
    inv_y0 = 84
    for r in range(3):
        draw_slot_row(img, 8, inv_y0 + r * 18, 9)
    hotbar_y = inv_y0 + 3 * 18 + 4
    draw_slot_row(img, 8, hotbar_y, 9)
    draw.line([(2, PANEL_H - 1), (PANEL_W - 3, PANEL_H - 1)], fill=ORANGE)
    out = os.path.join(OUT_DIR, "dispenser.png")
    img.save(out)
    print(f"wrote {out}  ({img.size[0]}x{img.size[1]})")


def render_shulker():
    """shulker_box.png — 176x166, 3x9 grid (same as 27-slot chest top half)."""
    img = Image.new("RGBA", (W_TEX, H_TEX), TRANS)
    draw = ImageDraw.Draw(img)
    PANEL_W = W_GUI
    PANEL_H = 166
    draw_panel_frame(draw, 0, 0, PANEL_W, PANEL_H)
    draw_title_bar(img, 0, 0, PANEL_W, 17)
    # 3 rows × 9 cols at (7, 17)
    for r in range(3):
        draw_slot_row(img, 7, 17 + r * 18, 9)
    inv_y0 = 84
    for r in range(3):
        draw_slot_row(img, 7, inv_y0 + r * 18, 9)
    hotbar_y = inv_y0 + 3 * 18 + 4
    draw_slot_row(img, 7, hotbar_y, 9)
    draw.line([(2, PANEL_H - 1), (PANEL_W - 3, PANEL_H - 1)], fill=ORANGE)
    out = os.path.join(OUT_DIR, "shulker_box.png")
    img.save(out)
    print(f"wrote {out}  ({img.size[0]}x{img.size[1]})")


if __name__ == "__main__":
    render_chest()
    render_inventory()
    render_hopper()
    render_dispenser()
    render_shulker()
