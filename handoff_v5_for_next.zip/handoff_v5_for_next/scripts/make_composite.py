#!/usr/bin/env python3
"""Render full in-game-style composite previews for the new GUI textures.

This goes beyond the simple texture crop: it scales up the texture to 4x
(matching how Minecraft renders GUI at the typical 2x GUI scale on
modern resolutions) and overlays a sample banner glyph in the title bar
to show how the full menu actually looks in game.
"""
import os
from PIL import Image, ImageDraw, ImageFont

PACK = "/home/ubuntu/work/new_pack/assets/minecraft/textures"
BANNERS = os.path.join(PACK, "font/banners")
OUT_DIR = "/home/ubuntu/work/preview"
os.makedirs(OUT_DIR, exist_ok=True)

SCALE = 4
ROOM_BG = (10, 8, 6, 255)  # simulated dark room behind the GUI


def make_chest_with_banner(banner_name: str, rows: int, out_name: str):
    chest = Image.open(os.path.join(PACK, "gui/container/generic_54.png")).convert("RGBA")
    banner = Image.open(os.path.join(BANNERS, banner_name)).convert("RGBA")

    top_h = 17 + rows * 18
    top = chest.crop((0, 0, 176, top_h))
    bot = chest.crop((0, 126, 176, 126 + 96))
    gui = Image.new("RGBA", (176, top_h + 96), (0, 0, 0, 0))
    gui.paste(top, (0, 0))
    gui.paste(bot, (0, top_h))

    # Overlay banner glyph at position (0, 0) — banner is 176×12.
    # Vanilla title baseline at y=6 with our ascent=10 height=12 means
    # glyph top is at y=6 - 10 = -4; clamp to y=-4. We draw at top=2 to
    # keep it in title bar visually (close enough to in-game look).
    gui.alpha_composite(banner, (0, 3))

    # Scale up
    gui = gui.resize((176 * SCALE, gui.size[1] * SCALE), Image.NEAREST)

    # Place on dark room background
    margin = 32
    canvas = Image.new(
        "RGBA",
        (gui.size[0] + 2 * margin, gui.size[1] + 2 * margin),
        ROOM_BG,
    )
    canvas.alpha_composite(gui, (margin, margin))

    canvas.save(os.path.join(OUT_DIR, out_name))
    print(f"wrote {out_name}  ({canvas.size})")


def make_collage(parts, out_name, cols=3):
    """Stitch multiple PNGs into a single labeled image."""
    imgs = [Image.open(os.path.join(OUT_DIR, p)).convert("RGBA") for p in parts]
    cell_w = max(i.size[0] for i in imgs)
    cell_h = max(i.size[1] for i in imgs)
    rows = (len(imgs) + cols - 1) // cols
    canvas = Image.new("RGBA", (cell_w * cols, cell_h * rows), ROOM_BG)
    for idx, im in enumerate(imgs):
        r = idx // cols
        c = idx % cols
        canvas.alpha_composite(
            im,
            (c * cell_w + (cell_w - im.size[0]) // 2,
             r * cell_h + (cell_h - im.size[1]) // 2),
        )
    canvas.save(os.path.join(OUT_DIR, out_name))
    print(f"wrote {out_name}  ({canvas.size})")


if __name__ == "__main__":
    make_chest_with_banner("menu.png",   6, "composite_menu_6row.png")
    make_chest_with_banner("donate.png", 6, "composite_donate_6row.png")
    make_chest_with_banner("shop.png",   6, "composite_shop_6row.png")
    make_chest_with_banner("portals.png", 5, "composite_portals_5row.png")
    make_chest_with_banner("rtp.png",    3, "composite_rtp_3row.png")
    make_chest_with_banner("help.png",   1, "composite_help_1row.png")
    make_collage(
        [
            "composite_menu_6row.png",
            "composite_donate_6row.png",
            "composite_shop_6row.png",
            "composite_portals_5row.png",
            "composite_rtp_3row.png",
            "composite_help_1row.png",
        ],
        "composite_grid.png",
        cols=3,
    )
