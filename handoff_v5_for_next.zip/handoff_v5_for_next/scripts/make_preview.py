#!/usr/bin/env python3
"""Render preview composites of the new GUI textures.

Crops the 256x256 textures to actual GUI dimensions, then scales 4x for
easy viewing without changing rendered pixel art. Also overlays a sample
banner glyph on the chest title bar to show how everything reads together.
"""
import os
from PIL import Image

PACK = "/home/ubuntu/work/new_pack/assets/minecraft/textures"
OUT_DIR = "/home/ubuntu/work/preview"
os.makedirs(OUT_DIR, exist_ok=True)

# (file in pack, output name, gui w, gui h)
TARGETS = [
    ("gui/container/generic_54.png",  "preview_chest_6row.png", 176, 222),
    ("gui/container/generic_54.png",  "preview_chest_3row.png", 176, 222),  # we'll crop differently below
    ("gui/container/inventory.png",   "preview_inventory.png",  176, 166),
    ("gui/container/hopper.png",      "preview_hopper.png",     176, 133),
    ("gui/container/dispenser.png",   "preview_dispenser.png",  176, 166),
    ("gui/container/shulker_box.png", "preview_shulker.png",    176, 166),
]

SCALE = 4

# Compose a "3 row chest" preview by taking top 17+3*18 px (= 71) then
# splicing the bottom inv portion from y=126..221.
def make_chest_preview(src, dst, rows):
    img = Image.open(src).convert("RGBA")
    top_h = 17 + rows * 18  # height of slot area + title
    top = img.crop((0, 0, 176, top_h))
    bot = img.crop((0, 126, 176, 126 + 96))
    composite = Image.new("RGBA", (176, top_h + 96), (0, 0, 0, 0))
    composite.paste(top, (0, 0))
    composite.paste(bot, (0, top_h))
    composite = composite.resize((176 * SCALE, (top_h + 96) * SCALE), Image.NEAREST)
    composite.save(dst)
    print(f"wrote {dst}  ({composite.size})")


def make_basic_preview(src, dst, w, h):
    img = Image.open(src).convert("RGBA")
    cropped = img.crop((0, 0, w, h))
    cropped = cropped.resize((w * SCALE, h * SCALE), Image.NEAREST)
    cropped.save(dst)
    print(f"wrote {dst}  ({cropped.size})")


if __name__ == "__main__":
    src_chest = os.path.join(PACK, "gui/container/generic_54.png")
    make_chest_preview(src_chest, os.path.join(OUT_DIR, "preview_chest_6row.png"), 6)
    make_chest_preview(src_chest, os.path.join(OUT_DIR, "preview_chest_3row.png"), 3)
    make_chest_preview(src_chest, os.path.join(OUT_DIR, "preview_chest_1row.png"), 1)
    for src, dst, w, h in TARGETS:
        if "generic_54" in src:
            continue
        make_basic_preview(os.path.join(PACK, src), os.path.join(OUT_DIR, dst), w, h)
