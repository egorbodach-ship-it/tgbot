#!/usr/bin/env python3
"""
Uploads every PNG in pack_overlays/ to
  /plugins/Oraxen/pack/textures/font/menus/<name>.png
on the server, plus uploads the Oraxen glyph definitions YAML.

After running this, call:
  oraxen reload all
  oraxen pack
to regenerate the pack.

Usage:
    PTERODACTYL_KEY=... python3 upload_pack_overlays.py
"""

from __future__ import annotations
import os, sys, urllib.parse, subprocess

KEY  = os.environ['PTERODACTYL_KEY']
BASE = 'https://mgr.hosting-minecraft.pro/api/client/servers/944c2567'
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PNGS = os.path.join(ROOT, 'pack_overlays')


def push(server_path: str, local_path: str) -> str:
    enc = urllib.parse.quote(server_path)
    r = subprocess.run([
        'curl', '-sf', '-X', 'POST',
        '-H', f'Authorization: Bearer {KEY}',
        '-H', 'Content-Type: application/octet-stream',
        '--data-binary', f'@{local_path}',
        f'{BASE}/files/write?file={enc}',
        '-w', '%{http_code}',
    ], capture_output=True, text=True)
    return r.stdout.strip()


def main():
    files = sorted(f for f in os.listdir(PNGS) if f.endswith('.png'))
    if not files:
        sys.exit(f'no PNGs in {PNGS}')
    print(f'uploading {len(files)} PNGs to /plugins/Oraxen/pack/textures/font/menus/')
    ok = 0
    for fn in files:
        local = os.path.join(PNGS, fn)
        code = push(f'/plugins/Oraxen/pack/textures/font/menus/{fn}', local)
        print(f'  {code:5s} {fn:20s} ({os.path.getsize(local)} B)')
        if code == '204':
            ok += 1

    print(f'\nPNGs: {ok}/{len(files)} uploaded')

    yml = os.path.join(ROOT, 'server_state', 'oraxen_glyphs_menus_overlay.yml')
    if os.path.exists(yml):
        code = push('/plugins/Oraxen/glyphs/menus_overlay.yml', yml)
        print(f'glyphs YAML: {code} ({os.path.getsize(yml)} B)')

    print('\n>> next: run `oraxen reload all` then `oraxen pack` over the API <<')


if __name__ == '__main__':
    main()
