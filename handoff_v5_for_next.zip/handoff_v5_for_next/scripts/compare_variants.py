#!/usr/bin/env python3
"""Build a side-by-side 3-up comparison of v1/v2/v3 menu textures."""
import os
from PIL import Image, ImageDraw, ImageFont

BANNERS = "/home/ubuntu/work/new_pack/assets/minecraft/textures/font/banners"
ROOM_BG = (10, 8, 6, 255)
SCALE = 4
OUT = "/home/ubuntu/work/preview/compare.png"


def compose(pack_path: str, banner_file: str = "menu.png", rows: int = 6) -> Image.Image:
    chest = Image.open(os.path.join(pack_path, "gui/container/generic_54.png")).convert("RGBA")
    banner = Image.open(os.path.join(BANNERS, banner_file)).convert("RGBA")
    top_h = 17 + rows * 18
    top = chest.crop((0, 0, 176, top_h))
    bot = chest.crop((0, 126, 176, 126 + 96))
    gui = Image.new("RGBA", (176, top_h + 96), (0, 0, 0, 0))
    gui.paste(top, (0, 0))
    gui.paste(bot, (0, top_h))
    gui.alpha_composite(banner, (0, 3))
    return gui.resize((176 * SCALE, gui.size[1] * SCALE), Image.NEAREST)


def labeled(img: Image.Image, label: str) -> Image.Image:
    label_h = 60
    out = Image.new("RGBA", (img.size[0], img.size[1] + label_h), ROOM_BG)
    out.alpha_composite(img, (0, label_h))
    d = ImageDraw.Draw(out)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
    except Exception:
        font = ImageFont.load_default()
    bbox = d.textbbox((0, 0), label, font=font)
    w = bbox[2] - bbox[0]
    d.text(((out.size[0] - w) // 2, 14), label, fill=(255, 138, 64, 255), font=font)
    return out


variants = [
    ("/home/ubuntu/work/new_pack/assets/minecraft/textures",
     "v1: рисованный (мой первый)"),
    ("/home/ubuntu/work/new_pack_v2/assets/minecraft/textures",
     "v2: жёсткий ретинт Dark Mode"),
    ("/home/ubuntu/work/new_pack_v3/assets/minecraft/textures",
     "v3: мягкий ретинт Dark Mode"),
]

images = [labeled(compose(p), lbl) for p, lbl in variants]
gap = 24
total_w = sum(i.size[0] for i in images) + gap * (len(images) + 1)
total_h = max(i.size[1] for i in images) + gap * 2
canvas = Image.new("RGBA", (total_w, total_h), ROOM_BG)
x = gap
for im in images:
    canvas.alpha_composite(im, (x, gap))
    x += im.size[0] + gap
canvas.save(OUT)
print("wrote", OUT, canvas.size)
