#!/usr/bin/env python3
"""
v4 generator — ornate orange/black overlay glyphs for DeluxeMenus.

Design constraints (from user 2026-05-12):
* Inspired by user_ref1_menu.png / user_ref2_shop.png — small title ribbon at
  top center, ornate corner-curl ornaments, decorative outer frame.
* Brand palette ONLY: #FF5700 orange + #FF8A40 highlight + #A03200 dark
  accent + black/dark-gray panel. NO purple, NO gold.
* Player inventory area is left 100% VANILLA (light gray). Glyph height covers
  only the chest-top section: 17 + rows*18 pixels tall.
* Vanilla chests and the player inventory must NOT be themed. We achieve this
  by overlaying via a custom bitmap font on the chest title only — see
  HANDOFF.md §4 for the math.

Outputs:
  /home/ubuntu/work/combined_pack/assets/minecraft/textures/font/menus/*.png
  /home/ubuntu/work/combined_pack/assets/minecraft/font/banners.json (extended
  with U+F001..U+F01C providers)
"""
from __future__ import annotations

import json
import os
from PIL import Image, ImageDraw

# ---- Brand palette ----
ORANGE      = (255,  87,   0, 255)   # #FF5700 primary
ORANGE_HI   = (255, 138,  64, 255)   # #FF8A40 highlight
ORANGE_DK   = (160,  50,   0, 255)   # #A03200 dark accent
BLACK       = ( 15,  15,  15, 255)   # #0F0F0F panel
DK_PANEL    = ( 28,  28,  28, 255)   # #1C1C1C
MID_PANEL   = ( 40,  40,  40, 255)   # #282828
SLOT_BG     = ( 24,  24,  24, 255)   # #181818
SLOT_HI     = ( 60,  60,  60, 255)   # #3C3C3C
SLOT_LO     = (  8,   8,   8, 255)   # #080808

# Vanilla chest GUI layout (1.16.5).
CHEST_W      = 176     # chest texture width
TITLE_BAR_H  = 17      # y=0..16 is the title-bar strip
SLOT_PITCH   = 18      # slot rows are 18 px on center
SLOT_X0      = 8       # leftmost slot column inner x
SLOT_Y0      = 18      # top slot row inner y
SLOT_INNER   = 16      # slot interior pixel size

# Overlay width — the title is drawn at chest_x=8 in vanilla 1.16.5, so an
# overlay of width W lands at chest_x=8..(8+W-1). With W=168 the right edge
# aligns perfectly with chest_x=175 (the chest's right edge). The leftmost
# 8 px column of the chest stays vanilla. This is the cleanest option with
# 1.16.5 fonts (no `space` provider available to shift negatively).
GLYPH_W      = 168
# Where the slot grid lives inside the glyph (slots are at chest_x=8.., glyph
# starts at chest_x=8 so the leftmost slot top-left in glyph coords is x=0).
GSLOT_X0     = 0
GSLOT_Y0     = 18

# Banner-codepoint -> banner PNG filename (existing, leave untouched).
BANNERS = {
    0xE001: 'menu',     0xE002: 'donate',   0xE003: 'shop',     0xE004: 'events',
    0xE005: 'help',     0xE006: 'portals',  0xE007: 'rtp',      0xE008: 'obmen',
    0xE009: 'arenda',   0xE00A: 'grab',     0xE00B: 'media',    0xE00C: 'freek',
    0xE00D: 'panel',    0xE00E: 'egorchik', 0xE00F: 'akriwer',  0xE010: 'arrow',
    0xE011: 'egg',      0xE012: 'items',    0xE013: 'livalka',  0xE014: 'potions',
    0xE015: 'pred',     0xE016: 'pve',      0xE017: 'pveother', 0xE018: 'resmenu',
    0xE019: 'reseuro',  0xE01A: 'resmoneta',0xE01B: 'shari',    0xE01C: 'spawners',
}

# Menu codepoint -> row count (from server-side DeluxeMenus YAMLs, see HANDOFF §5).
MENU_ROWS = {
    0xE001: 6, 0xE002: 5, 0xE003: 6, 0xE004: 5, 0xE005: 5, 0xE006: 5, 0xE007: 5,
    0xE008: 3, 0xE009: 5, 0xE00A: 5, 0xE00B: 5, 0xE00C: 6, 0xE00D: 5, 0xE00E: 5,
    0xE00F: 5, 0xE010: 5, 0xE011: 6, 0xE012: 6, 0xE013: 5, 0xE014: 6, 0xE015: 5,
    0xE016: 5, 0xE017: 5, 0xE018: 5, 0xE019: 5, 0xE01A: 5, 0xE01B: 6, 0xE01C: 5,
}

OUT_DIR   = "/home/ubuntu/work/combined_pack/assets/minecraft"
OUT_TEX   = os.path.join(OUT_DIR, "textures/font/menus")
OUT_FONT  = os.path.join(OUT_DIR, "font/banners.json")
BANNER_TEX = "/home/ubuntu/work/current_pack/textures/font/banners"
os.makedirs(OUT_TEX, exist_ok=True)
os.makedirs(os.path.dirname(OUT_FONT), exist_ok=True)


# ---------- pixel-art primitives ----------

def hline(d, x0, x1, y, c):
    d.line([(x0, y), (x1, y)], fill=c)


def vline(d, x, y0, y1, c):
    d.line([(x, y0), (x, y1)], fill=c)


def rect_outline(d, x0, y0, x1, y1, c):
    d.rectangle([x0, y0, x1, y1], outline=c)


# ---------- frame + interior ----------

def draw_chest_panel(img: Image.Image, w: int, h: int) -> None:
    """4-pixel ornate orange frame + dark interior. Pixel-art bevel."""
    d = ImageDraw.Draw(img)
    # Solid dark interior fill.
    d.rectangle([0, 0, w - 1, h - 1], fill=BLACK)
    # Four-band frame from outside in:
    #   row 0: dark shadow
    #   row 1: main orange
    #   row 2: bright highlight
    #   row 3: dark inner separator (gives depth before interior)
    rect_outline(d, 0, 0, w - 1, h - 1, ORANGE_DK)
    rect_outline(d, 1, 1, w - 2, h - 2, ORANGE)
    rect_outline(d, 2, 2, w - 3, h - 3, ORANGE_HI)
    rect_outline(d, 3, 3, w - 4, h - 4, ORANGE_DK)


# Hand-coded 20x20 ornate top-left corner. Each character = 1 pixel.
#   . transparent (let frame show through)
#   D dark outline (ORANGE_DK)
#   X main orange (ORANGE)
#   H bright highlight (ORANGE_HI)
#   B black (BLACK) — sits OVER the frame to carve a notch
CURL_TL = [
    "DDDDDDDDDDDDDDDDDDDD",
    "DXXXXXXXXXXXXXXXXXXD",
    "DXHHHHHHHHHHHHHHHHXD",
    "DXHDDDDDDDDDDDDDDHXD",
    "DXHDXXXXXXXXXXXXDHXD",
    "DXHDXHHHHHHHHHHXDHXD",
    "DXHDXHDDDDDDDDHXDHXD",
    "DXHDXHDXXXXXXDHXDHX.",
    "DXHDXHDXHHHHXDHXDHX.",
    "DXHDXHDXHDDHXDHXDH..",
    "DXHDXHDXHDHHXDHXDD..",
    "DXHDXHDXHDDDDDHXD...",
    "DXHDXHDXHHHHHHHXD...",
    "DXHDXHDXXXXXXXXX....",
    "DXHDXHDDDDDDDDD.....",
    "DXHDXXXXXXXXXX......",
    "DXHDDDDDDDDDDD......",
    "DXHHHHHHHHHHH.......",
    "DXXXXXXXXXXX........",
    "DDDDDDDDDDDD........",
]
CURL_COLORS = {"D": ORANGE_DK, "X": ORANGE, "H": ORANGE_HI, "B": BLACK}


def draw_corner_curl_tl(img: Image.Image, ox: int, oy: int) -> None:
    """Stamp the 20x20 top-left ornate curl into `img` at (ox, oy)."""
    px = img.load()
    for j, row in enumerate(CURL_TL):
        for i, ch in enumerate(row):
            c = CURL_COLORS.get(ch)
            if c is not None:
                px[ox + i, oy + j] = c


def draw_corner_curl(img: Image.Image, w: int, h: int) -> None:
    """All four ornate corner curls (TL/TR/BL/BR). TR/BL/BR mirror the TL stamp."""
    cell = len(CURL_TL)   # 20
    # Render TL into its own buffer so we can flip cheaply.
    tl = Image.new("RGBA", (cell, cell), (0, 0, 0, 0))
    draw_corner_curl_tl(tl, 0, 0)
    img.alpha_composite(tl, (0, 0))
    img.alpha_composite(tl.transpose(Image.FLIP_LEFT_RIGHT), (w - cell, 0))
    img.alpha_composite(tl.transpose(Image.FLIP_TOP_BOTTOM), (0, h - cell))
    img.alpha_composite(
        tl.transpose(Image.FLIP_LEFT_RIGHT).transpose(Image.FLIP_TOP_BOTTOM),
        (w - cell, h - cell),
    )


# ---------- subtle slot grid ----------

def draw_slots(img: Image.Image, rows: int) -> None:
    """
    Very subtle 9 x rows slot outlines drawn in dark grey.
    Items in DeluxeMenus render on top of the texture, so the outline acts as
    a faint reference; we keep it muted so the orange frame stays the main
    visual element (matches user references). Glyph is 168 wide and starts at
    chest_x=8, so slot 0 is at glyph_x=0.
    """
    d = ImageDraw.Draw(img)
    for r in range(rows):
        for c in range(9):
            x = GSLOT_X0 + c * SLOT_PITCH
            y = GSLOT_Y0 + r * SLOT_PITCH
            d.rectangle([x, y, x + SLOT_INNER - 1, y + SLOT_INNER - 1],
                        outline=SLOT_HI)
            # 1 px inner shadow on top-left (subtle inset).
            d.point((x, y), SLOT_LO)
            d.point((x + 1, y), SLOT_LO)
            d.point((x, y + 1), SLOT_LO)


# ---------- title ribbon ----------

def draw_title_ribbon(img: Image.Image, banner_path: str, w: int) -> None:
    """
    Compose a centered ~96px-wide ribbon containing the banner's title text.
    The existing banner PNGs are 176 wide (chest-wide), but the title text is
    only in the central ~64 px. We crop that central text region and place it
    inside a small ornate ribbon at the top center of the overlay, so the
    overall look matches the user references (small title ribbon, not a full
    chest-wide bar).
    """
    banner = Image.open(banner_path).convert("RGBA")
    # Banner layout (v3 banners): orange notch + dark+orange center with white
    # text + orange notch. The text is roughly in glyph_x 40..136 (96 px wide).
    text_crop = banner.crop((40, 0, 136, banner.height))     # 96 x 12
    ribbon_w = text_crop.width + 14                           # 110 px wide
    ribbon_h = 13                                              # 13 px tall
    ribbon = Image.new("RGBA", (ribbon_w, ribbon_h), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ribbon)
    # Pointed/notched ribbon shape:
    #   left notch (\) and right notch (/) — 5 px wide each
    #   center rectangle — 100 px wide, 13 px tall
    # Outer dark outline
    rd.polygon([(0, 6), (5, 0), (ribbon_w - 6, 0), (ribbon_w - 1, 6),
                (ribbon_w - 6, ribbon_h - 1), (5, ribbon_h - 1)],
               fill=ORANGE_DK)
    # Main orange fill 1 px inside
    rd.polygon([(2, 6), (6, 1), (ribbon_w - 7, 1), (ribbon_w - 3, 6),
                (ribbon_w - 7, ribbon_h - 2), (6, ribbon_h - 2)],
               fill=ORANGE)
    # Top highlight line
    rd.line([(6, 1), (ribbon_w - 7, 1)], fill=ORANGE_HI)
    rd.line([(2, 6), (6, 2)], fill=ORANGE_HI)
    rd.line([(ribbon_w - 3, 6), (ribbon_w - 7, 2)], fill=ORANGE_HI)
    # Center dark text area so white text stays readable
    rd.rectangle([8, 2, ribbon_w - 9, ribbon_h - 3], fill=BLACK)
    # Drop in the text crop (offset to land inside the dark area)
    ribbon.alpha_composite(text_crop, (7, (ribbon_h - text_crop.height) // 2))
    # Place ribbon centered horizontally at y=2 (overlaps the top frame band).
    rx = (w - ribbon_w) // 2
    img.alpha_composite(ribbon, (rx, 2))


# ---------- compose ----------

def compose_combined(banner_name: str, rows: int) -> Image.Image:
    """Build one full overlay glyph. Width GLYPH_W; height 17 + rows*18."""
    h = TITLE_BAR_H + rows * SLOT_PITCH
    img = Image.new("RGBA", (GLYPH_W, h), (0, 0, 0, 0))
    draw_chest_panel(img, GLYPH_W, h)
    # Subtle slot grid (mutes the dark interior so 9xN structure is hinted).
    draw_slots(img, rows)
    # Ornate corners on top so they hide the slot lines underneath.
    draw_corner_curl(img, GLYPH_W, h)
    # Title ribbon centered at top.
    banner_path = os.path.join(BANNER_TEX, banner_name + ".png")
    draw_title_ribbon(img, banner_path, GLYPH_W)
    return img


def main() -> None:
    providers = []
    # Keep the existing E001..E01C banner providers untouched (DeluxeMenus
    # YAMLs still reference these for the small-ribbon test pass).
    for cp, name in BANNERS.items():
        providers.append({
            "type": "bitmap",
            "file": f"minecraft:font/banners/{name}.png",
            "ascent": 10,
            "height": 12,
            "chars": [chr(cp)],
        })
    # Combined F001..F01C providers — full-chest-top overlays.
    for cp, name in BANNERS.items():
        rows = MENU_ROWS[cp]
        img = compose_combined(name, rows)
        out_path = os.path.join(OUT_TEX, name + ".png")
        img.save(out_path)
        cp_combined = cp + 0x1000
        providers.append({
            "type": "bitmap",
            "file": f"minecraft:font/menus/{name}.png",
            "ascent": 13,
            "height": img.height,
            "chars": [chr(cp_combined)],
        })
        print(f"  {name:11s} rows={rows} size={img.size} cp=U+{cp_combined:04X}")

    with open(OUT_FONT, "w", encoding="utf-8") as f:
        json.dump({"providers": providers}, f, ensure_ascii=False, indent=2)
    print(f"\nWrote {OUT_FONT}")
    print(f"Generated {len(BANNERS)} ornate overlays in {OUT_TEX}")


if __name__ == "__main__":
    main()
