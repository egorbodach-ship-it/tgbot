# Diagnose-the-render checklist

When the user says "the menu doesn't look right", run through THIS list before changing anything.

## A. Is the pack reaching the client?

1. Read `server.properties`:
   ```bash
   ENC=$(python3 -c "import urllib.parse;print(urllib.parse.quote('/server.properties'))")
   curl -sf -H "Authorization: Bearer $PTERODACTYL_KEY" "$BASE/files/contents?file=$ENC" | grep resource-pack
   ```
   - The URL should match the `id=<hash>` in the most recent `Oraxen | Resourcepack uploaded on url ...` log line.
   - `resource-pack-sha1` MUST exactly equal `id=` and be a 40-hex-char string.

2. Tail `logs/latest.log` and look for the latest line of the form:
   ```
   Oraxen | Resourcepack uploaded on url http://atlas.oraxen.com:8080/pack.zip?id=<HASH> in <N> ms
   ```
   If that line is older than the last edit you made → run `oraxen pack` over the API.

3. Download the live pack and verify content:
   ```bash
   curl -s "http://atlas.oraxen.com:8080/pack.zip?id=<HASH>" -o /tmp/p.zip
   unzip -t /tmp/p.zip | tail -3                      # must say "No errors detected"
   unzip -p /tmp/p.zip pack.mcmeta                    # must contain "pack_format": 6
   unzip -l /tmp/p.zip | grep -c "font/menus/.*png"   # must be 28
   ```
   - If `unzip -t` complains about bad CRCs → re-disable `Pack.generation.protection` in `/plugins/Oraxen/settings.yml`.
   - If `pack_format` is 7 → Oraxen forgot the pack_format override for 1.16; force it manually inside `pack/pack.mcmeta` before next build. (Note: 1.16.5 requires 6.)

4. Ask the user to fully disconnect & reconnect. The client caches packs by hash; only a fresh handshake re-downloads.

## B. Are the glyphs in the default font?

```bash
unzip -p /tmp/p.zip assets/minecraft/font/default.json | \
  jq '.providers[] | select(.file|test("font/menus/")) | {file, chars}'
```
- Must list 28 entries.
- Each char should be in the **Tamil block** `U+0BC0..U+0BE3` (Oraxen-assigned).
- If a glyph is missing → check `/plugins/Oraxen/glyphs/menus_overlay.yml`. Reload pack.

## C. Are the YAML titles using the *current* codepoints?

```bash
ENC=$(python3 -c "import urllib.parse;print(urllib.parse.quote('/plugins/DeluxeMenus/gui_menus/menu/menu.yml'))")
curl -sf -H "Authorization: Bearer $PTERODACTYL_KEY" "$BASE/files/contents?file=$ENC" | head -1 | xxd | head -2
```
- The bytes between `"..."` must encode the codepoint that `default.json` assigned to the `menu` glyph.
- If they don't match, the codepoints drifted (Oraxen reshuffled). Re-run `scripts/bulk_patch_titles.py`.

## D. Test rendering minimally

1. Plain text test:
   `menu_title: "DEVIN_TEST_123"` → renders verbatim → confirms DM reads YAML and reloads.
2. Raw codepoint test:
   `menu_title: "<single-char>"` → renders bitmap from default font.
   - If renders as missing-glyph (□): glyph not in default.json → re-do step B.
   - If renders fine: title strip is working — the remaining "problem" is the chest interior (see HANDOFF_v5.md §5/§6).

## E. Did I accidentally hit the player inventory?

```bash
unzip -l /tmp/p.zip | grep -E "gui/(container|inventory)" || echo "OK — vanilla gui untouched"
```
The pack MUST NOT contain `assets/minecraft/textures/gui/container/generic_54.png` or `gui/inventory.png`.
If it does — the user will be angry. Remove and rebuild.
