#!/usr/bin/env python3
"""Generate /menu /shop /donate /rtp /help previews with v3 textures."""
import os
from PIL import Image

PACK = "/home/ubuntu/work/new_pack_v3/assets/minecraft/textures"
SCALE = 4
ROOM_BG = (10, 8, 6, 255)

SCENARIOS = [
    ("menu_6row",    "menu.png",     6),
    ("shop_6row",    "shop.png",     6),
    ("donate_6row",  "donate.png",   6),
    ("portals_5row", "portals.png",  5),
    ("rtp_3row",     "rtp.png",      3),
    ("help_1row",    "help.png",     1),
]


def compose(banner_file: str, rows: int) -> Image.Image:
    chest = Image.open(os.path.join(PACK, "gui/container/generic_54.png")).convert("RGBA")
    banner = Image.open(os.path.join(PACK, "font/banners", banner_file)).convert("RGBA")
    top_h = 17 + rows * 18
    top = chest.crop((0, 0, 176, top_h))
    bot = chest.crop((0, 126, 176, 126 + 96))
    gui = Image.new("RGBA", (176, top_h + 96), (0, 0, 0, 0))
    gui.paste(top, (0, 0))
    gui.paste(bot, (0, top_h))
    gui.alpha_composite(banner, (0, 3))
    gui = gui.resize((176 * SCALE, gui.size[1] * SCALE), Image.NEAREST)
    bg = Image.new("RGBA", (gui.size[0] + 64, gui.size[1] + 64), ROOM_BG)
    bg.alpha_composite(gui, (32, 32))
    return bg


outputs = []
for name, banner_file, rows in SCENARIOS:
    img = compose(banner_file, rows)
    p = f"/home/ubuntu/work/preview/v3_{name}.png"
    img.save(p)
    outputs.append((p, img.size))
    print("✓", p, img.size)

# 3x2 grid collage
gap = 24
w0 = max(s[0] for _, s in outputs)
h_top = max(o[1][1] for o in outputs[:3])
h_bot = max(o[1][1] for o in outputs[3:])
canvas_w = 3 * w0 + 4 * gap
canvas_h = h_top + h_bot + 3 * gap
canvas = Image.new("RGBA", (canvas_w, canvas_h), ROOM_BG)
x = gap
for p, _ in outputs[:3]:
    im = Image.open(p)
    canvas.alpha_composite(im, (x, gap))
    x += w0 + gap
x = gap
y = h_top + 2 * gap
for p, _ in outputs[3:]:
    im = Image.open(p)
    canvas.alpha_composite(im, (x, y))
    x += w0 + gap
canvas.save("/home/ubuntu/work/preview/v3_grid.png")
print("collage at /home/ubuntu/work/preview/v3_grid.png", canvas.size)
