# HANDOFF — Grief Server GUI Texture Pack (v3, 2026-05-12)

> **Reader: this file is the source of truth for the next Devin/AI session.**
> Read this top-to-bottom before doing anything. It documents the current
> deploy state, the Oraxen-based pack workflow, the glyph-overlay math
> needed to put orange-black menu backgrounds on top of vanilla chests
> WITHOUT modifying `generic_54.png`, and every script / file path /
> codepoint / curl recipe needed to continue.

---

## 0. TL;DR — Current State

* **Server:** Pterodactyl ID `944c2567` — Paper 1.16.5 + Oraxen v1.119.0 (pirate from `black-minecraft.com`).
* **Panel:** https://mgr.hosting-minecraft.pro/server/944c2567
* **Pterodactyl API base:** `https://mgr.hosting-minecraft.pro/api/client/servers/944c2567`
* **Pterodactyl API key:** stored in the `KEY` env var (Bearer token, user-scoped, permanent).
* **Live pack served by Oraxen:** rebuilt with `o reload pack` on every change.
* **Deployed right now in `/plugins/Oraxen/pack/`:**
  - `font/banners.json` — 28 banner providers (U+E001..U+E01C) + 28 combined-glyph providers (U+F001..U+F01C, NOT YET DEPLOYED — see §5).
  - `textures/font/banners/*.png` — 28 banner PNGs (176×12 each, title text).
  - **Container GUI textures are NOT overridden** (we removed `generic_54.png`, `inventory.png`, `hopper.png`, `dispenser.png`, `shulker_box.png` on 2026-05-12 18:30 UTC because the user explicitly said vanilla chests + player inventory must look vanilla).
* **DeluxeMenus YAMLs:** 28 menus in `/plugins/DeluxeMenus/gui_menus/{menu,shop}/*.yml`.
  Each has `menu_title: '<font:minecraft:banners>\uE0XX</font>'` referencing one of the U+E001..U+E01C banner glyphs.
* **Next step the user wants:** make the WHOLE menu interior look orange-black-themed (decorative frame, slot bevels, etc.) but **only when DeluxeMenus is open**, not for vanilla chests or the player inventory. The user sent two screenshots (`refs/user_ref1_menu.png`, `refs/user_ref2_shop.png`) showing the ornate style they want **in our brand colors** — not 1:1 copies.

---

## 1. Brand & Palette

* Orange primary: `#FF5700` (RGB 255 87 0)
* Orange highlight: `#FF8A40`
* Orange dark accent: `#A03200`
* Panel black: `#0F0F0F`
* Panel dark: `#1C1C1C`
* Panel mid: `#282828`
* Slot bg: `#181818`
* Slot bevel hi: `#3C3C3C`
* Slot bevel lo: `#080808`
* Banner text font: DejaVu Sans Bold (used for banner PNG generation).

---

## 2. Oraxen Resource-Pack Pipeline

**The critical fact that breaks most attempts:** Oraxen intercepts resource-pack delivery.

* `server.properties` `resource-pack=...` URL is **IGNORED**. Oraxen overrides it via ProtocolLib packet (`AdvancedPackSender`).
* The pack Oraxen ships to players is built from `/plugins/Oraxen/pack/<X>` where `<X>` is mapped to `assets/minecraft/<X>` in the generated zip.
* Auto-upload target: `http://atlas.oraxen.com:8080/pack.zip?id=<sha1>`.
* `mandatory: true` is set in `/plugins/Oraxen/settings.yml`, so clients cannot decline (they'd be disconnected).

### 2.1 File-system layout in `/plugins/Oraxen/pack/`

```
/plugins/Oraxen/pack/
  font/
    banners.json                            # bitmap font providers (28 banners + 28 combined glyphs)
  textures/
    font/
      banners/<name>.png  (176×12)          # title-bar ribbons (current 28 — see §6 codepoint map)
      menus/<name>.png    (176×varies)      # FULL menu backgrounds — NOT DEPLOYED YET
    # gui/container/* — DO NOT add files here. We removed them on 2026-05-12 because
    # generic_54.png is shared between DeluxeMenus and vanilla chests. The user wants
    # vanilla chests untouched. Everything must go through the title-overlay glyph trick.
```

### 2.2 Regenerating the pack

```bash
# Tell Oraxen to rebuild + re-upload the pack.zip
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"o reload pack"}' \
  https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/command
# Wait ~5–8 s, then check logs for the new URL:
PATH=$(python3 -c "import urllib.parse; print(urllib.parse.quote('/logs/latest.log'))")
curl -sf -H "Authorization: Bearer $KEY" \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/files/contents?file=$PATH" \
  | grep -i "Resourcepack uploaded"
```

Look for `Oraxen | Resourcepack uploaded on url http://atlas.oraxen.com:8080/pack.zip?id=<HASH>`. That hash changes each rebuild.

### 2.3 Verifying contents of the live pack

```bash
curl -s "http://atlas.oraxen.com:8080/pack.zip?id=<HASH>" -o /tmp/pack.zip
unzip -l /tmp/pack.zip | grep -E "container|font/banners|font/menus"
```
Oraxen intentionally writes "bad CRC" warnings into the zip (obfuscation). Ignore them — content is fine, just extract with `unzip -o` or read entries directly.

---

## 3. Pterodactyl API Cheat-Sheet

All requests need:
```
Authorization: Bearer $KEY
```

### 3.1 Read a file

```bash
ENC=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" \
      "/plugins/Oraxen/pack/font/banners.json")
curl -sf -H "Authorization: Bearer $KEY" \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/files/contents?file=$ENC"
```

### 3.2 Write a file

> ⚠️ Content-Type **MUST** be `application/octet-stream`. `text/plain` sometimes returns HTTP 502.

```bash
ENC=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" \
      "/plugins/Oraxen/pack/textures/font/menus/menu.png")
curl -s -X POST \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/octet-stream" \
  --data-binary @./menu.png \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/files/write?file=$ENC" \
  -w "HTTP %{http_code}\n"
# HTTP 204 = success
# HTTP 502 = transient gateway error; retry once with 0.5 s delay
```

### 3.3 List a directory

```bash
ENC=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" \
      "/plugins/DeluxeMenus/gui_menus/menu")
curl -s -H "Authorization: Bearer $KEY" \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/files/list?directory=$ENC" \
  | python3 -m json.tool
```

### 3.4 Delete files (in same directory)

```bash
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"root":"/plugins/Oraxen/pack/textures/gui/container","files":["generic_54.png","inventory.png"]}' \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/files/delete" \
  -w "HTTP %{http_code}\n"
```

### 3.5 Send a server console command

```bash
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"o reload pack"}' \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/command" \
  -w "HTTP %{http_code}\n"
```

### 3.6 Restart server (rarely needed — `o reload pack` is enough for texture changes)

```bash
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"signal":"restart"}' \
  "https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/power" \
  -w "HTTP %{http_code}\n"
```

---

## 4. The Title-Overlay Glyph Trick (the only way to "theme" menus without breaking vanilla chests in 1.16.5)

### 4.1 Why we can't override `generic_54.png`

Minecraft uses **one** texture file (`assets/minecraft/textures/gui/container/generic_54.png`) for every 54-slot container — vanilla chests, double chests, ender chest, AND DeluxeMenus. Overriding it themes ALL of them, including any normal chest in the world. The user explicitly forbids that.

### 4.2 What we do instead

* We leave `generic_54.png` alone.
* In each DeluxeMenus YAML we set `menu_title` to a string containing a **single custom unicode glyph** rendered via a custom bitmap font.
* That glyph's image is sized so it **overlays the entire visible part of the chest** when MC draws the title.
* Vanilla chests have plain titles like `"Chest"`, so they never receive this overlay.

### 4.3 Glyph rendering math (verified empirically against the existing 176×12 banners)

```
drawString(text, x=8, y=6)   # vanilla 1.16.5 ContainerScreen.renderLabels()

For a bitmap glyph with ascent=A and height=H, rendered as the title:
    glyph TOP    (chest_y) = 6 + 7 - A     = 13 - A
    glyph BOTTOM (chest_y) = TOP + H - 1   = 12 - A + H
    glyph LEFT   (chest_x) = 8             (fixed; titleX is hardcoded to 8 in MC 1.16.5)
    glyph WIDTH  (rendered) = bitmap_width × (H / bitmap_height)
    cursor advance after glyph = rendered_width + 1
```

**Where 7 comes from:** the default font has `ascent=7 height=8`. The baseline of the line is at `drawString_y + ascent_default - 1 = 6 + 7 - 1 = 12`. A glyph with ascent A places its TOP at `baseline - A + 1 = 13 - A`.

### 4.4 Concrete glyph parameters for full-chest overlay

```
6-row chest (size 54 / 53 / 55 from DM):  total height = 17 + 6×18 + 96 = 221 + 1 frame = 222
5-row chest (size 45 / 44):                17 + 5×18 + 96 = 203 + 1 = 204
3-row chest (size 27):                     17 + 3×18 + 96 = 149 + 1 = 150
```

Choose `ascent` so glyph TOP = 0 (top of chest texture):
```
ascent = 13 - 0 = 13
```

So every overlay glyph uses **`ascent: 13`** and `height` = the appropriate menu total height above.

`bitmap_width` (= PNG width) determines the rendered horizontal width. The vanilla title is drawn at chest_x=8, so:

| PNG width | Renders at chest_x | Notes |
|-----------|--------------------|-------|
| 176       | 8..183             | Existing banners use this. 8 px overflow past chest right edge. Design appears 8 px right of chest center. The user previously accepted this. |
| 168       | 8..175             | Perfect right alignment with chest. Loses chest_x=0..7 (8 px vanilla strip on left). |

Recommendation: **use 176** to match the banner behavior and keep things consistent. If the 8 px right-offset looks off in-game, drop to 168 in a single config flip.

### 4.5 Why we cannot do negative x-shift in 1.16.5

* MC 1.16.5 only supports `bitmap`, `legacy_unicode`, and `ttf` font providers — **NOT `space`** (added in 1.20).
* For `bitmap`, the per-char advance is auto-computed and always positive. There is no way to set a negative-width glyph.
* Therefore: we cannot center the overlay perfectly on the chest. We accept the 8 px asymmetry (or design the PNG content to be intentionally shifted 8 px left so the visible center lands on chest center).

### 4.6 Codepoint convention

* `U+E001..U+E01C` — existing 176×12 banner glyphs (title text ribbons). KEEP. Already used by every DeluxeMenus YAML.
* `U+F001..U+F01C` — combined full-menu-background glyphs (NEW, to be deployed). Each = `0xE0XX + 0x1000`.
* When deploying overlays, change `menu_title` from `<font:minecraft:banners>\uE0XX</font>` to `<font:minecraft:banners>\uF0XX</font>` for each menu.

---

## 5. Codepoint ⇄ Menu ⇄ Size Map

Scanned from production YAMLs in `/plugins/DeluxeMenus/gui_menus/{menu,shop}/` on 2026-05-12. Sizes are DeluxeMenus' `size:` values; DM rounds up to the next multiple of 9 (so 44 → 5 rows, 53/55 → 6 rows, 27 → 3 rows).

| Banner CP | Combined CP | Menu file                              | Size | Rows | Title text |
|-----------|-------------|----------------------------------------|------|------|-----------|
| U+E001    | U+F001      | menu/menu.yml                          | 54   | 6    | МЕНЮ      |
| U+E002    | U+F002      | menu/donate.yml                        | 44   | 5    | ДОНАТ     |
| U+E003    | U+F003      | shop/donateSHOP.yml                    | 53   | 6    | МАГАЗИН   |
| U+E004    | U+F004      | menu/events.yml                        | 45   | 5    | СОБЫТИЯ   |
| U+E005    | U+F005      | menu/help.yml                          | 44   | 5    | ПОМОЩЬ    |
| U+E006    | U+F006      | menu/portals.yml                       | 45   | 5    | ПОРТАЛЫ   |
| U+E007    | U+F007      | menu/rtp.yml                           | 44   | 5    | RTP       |
| U+E008    | U+F008      | menu/obmen.yml                         | 27   | 3    | ОБМЕН     |
| U+E009    | U+F009      | menu/arenda.yml                        | 44   | 5    | АРЕНДА    |
| U+E00A    | U+F00A      | menu/grab.yml                          | 44   | 5    | ГРАБ      |
| U+E00B    | U+F00B      | menu/media.yml                         | 44   | 5    | МЕДИА     |
| U+E00C    | U+F00C      | menu/freek.yml                         | 54   | 6    | ФРИКЕЙ    |
| U+E00D    | U+F00D      | menu/panel.yml                         | 45   | 5    | ПАНЕЛЬ    |
| U+E00E    | U+F00E      | menu/egorchik.yml                      | 45   | 5    | ЕГОРЧИК   |
| U+E00F    | U+F00F      | menu/akriwer{,1,2}.yml                 | 45   | 5    | АКРИВЕР   |
| U+E010    | U+F010      | shop/donateARROW.yml                   | 44   | 5    | СТРЕЛЫ    |
| U+E011    | U+F011      | shop/donateEGG.yml                     | 54   | 6    | СПАВНЕРЫ-Я |
| U+E012    | U+F012      | shop/donateITEMS2.yml                  | 54   | 6    | ВЕЩИ      |
| U+E013    | U+F013      | shop/donateLIVALKA.yml                 | 44   | 5    | ЗЕЛЬЯ-Х   |
| U+E014    | U+F014      | shop/donatePOTIONS.yml                 | 55   | 6    | ЗЕЛЬЯ     |
| U+E015    | U+F015      | shop/donatePRED.yml                    | 45   | 5    | ПРЕДМ.    |
| U+E016    | U+F016      | shop/donatePVE.yml                     | 45   | 5    | PVE       |
| U+E017    | U+F017      | shop/donatePVEOTHER.yml                | 45   | 5    | PVE-ДР    |
| U+E018    | U+F018      | shop/donateRESMENU.yml                 | 45   | 5    | РЕС-МЕНЮ  |
| U+E019    | U+F019      | shop/donateRESEURO.yml                 | 44   | 5    | РЕС-€     |
| U+E01A    | U+F01A      | shop/donateRESMONETA.yml               | 44   | 5    | РЕС-МОНЕТА|
| U+E01B    | U+F01B      | shop/donateSHARI.yml                   | 54   | 6    | ШАРЫ      |
| U+E01C    | U+F01C      | shop/donateSPAWNERS.yml                | 45   | 5    | СПАВНЕРЫ  |

> `menu/masks.yml` and `shop/masks.yml` (both `size:54`) currently use plain text titles (`'&8&l> &0Маски &7| &0/masks'`) — no glyph. Leave them alone unless the user asks to theme them too.

---

## 6. Source Scripts (all in `/home/ubuntu/work/`)

### `gen_combined_glyphs.py`
Generates the 28 combined-background PNGs and the extended `font/banners.json`. Output goes to `/home/ubuntu/work/combined_pack/assets/minecraft/`. Tweak the `compose_combined()` function to change the design (frame style, corner ornaments, slot bevel pattern). Current implementation is a placeholder using simple orange-frame + dark slots. **NEXT TASK: make it ornate to match the user's reference screenshots.**

### `upload_to_oraxen.py`
Batch-upload script. Strips `assets/minecraft/` prefix from local paths and POSTs each file to `/plugins/Oraxen/pack/<rest>` via the Pterodactyl write endpoint. Handles 502 retries.

### `retint_subtle.py` / `retint_dark_mode.py`
Earlier experiments: retint the AGPL-3.0 Dark Mode GUI pack (Modrinth `cmI4DUoF`) into our palette. NOT deployed (we no longer override `generic_54.png`). Keep them around for reference — they show how brightness-based palette mapping works (see "Color mapping philosophy" in §9).

### `gen_gui.py`
Original from-scratch GUI generator. Produces `generic_54.png` / `inventory.png` / `hopper.png` / `dispenser.png` / `shulker_box.png` (256×256 each) with the v1 hand-drawn style. **Do NOT redeploy these to `/plugins/Oraxen/pack/textures/gui/container/`** — they'd theme vanilla chests too.

### `make_preview.py` / `make_composite.py`
Renders mock composites of menus with banner overlay for visual review. Useful to iterate on the design without deploying every time.

### `compare_variants.py`
Builds the v1/v2/v3 side-by-side comparison image (`preview/compare.png`). Used to show the user the three design candidates before they picked.

### `preview_overlay.py`
Simulates how a combined glyph would render on top of vanilla chest (using a synthetic vanilla chest stand-in). Use this to validate the design BEFORE deploying.

### `make_v3_previews.py`
Generates 6 per-menu previews (MENU / SHOP / DONATE / PORTALS / RTP / HELP) and a 2×3 grid collage. Run again after any design change.

---

## 7. Workflow for Continuing Work

### 7.1 To redesign the combined glyphs

1. Edit `compose_combined()` in `gen_combined_glyphs.py` — adjust frame style, corner ornaments, slot bevel pattern.
2. Run `python3 gen_combined_glyphs.py` — outputs to `combined_pack/`.
3. Run `python3 preview_overlay.py` — visual check.
4. Iterate on `compose_combined()` until happy.

### 7.2 To deploy the combined glyphs

```bash
# 1) Upload all menu background PNGs
python3 upload_to_oraxen.py   # already configured to send combined_pack/* to /plugins/Oraxen/pack/

# 2) Upload the updated font/banners.json (extended with F-codepoints)

# 3) For each menu YAML, replace the banner codepoint with the combined codepoint:
#    s/\uE001/\uF001/  (for menu/menu.yml — see codepoint map in §5)
#    Use update_menu_titles.py (TODO: create — currently manual via Pterodactyl write API).

# 4) Reload Oraxen pack:
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"o reload pack"}' \
  https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/command

# 5) Reload DeluxeMenus to pick up YAML changes:
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"dm reload"}' \
  https://mgr.hosting-minecraft.pro/api/client/servers/944c2567/command

# 6) Verify in logs and ask user to reconnect (forced because mandatory=true)
```

### 7.3 To roll back

* Re-upload the old `font/banners.json` (preserve a copy in `/home/ubuntu/work/backups/` before each deploy).
* Revert `menu_title` in each YAML to U+E0XX codepoints.
* `o reload pack` + `dm reload`.

---

## 8. Design Reference (what the user wants the menu to look like)

The user sent two screenshots from another server / pack:

* `refs/user_ref1_menu.png` — МЕНЮ menu, ornate purple+gold+orange frame with corner curls, small title ribbon at top center, 3×3 item grid inside a solid orange panel, vanilla player inventory below.
* `refs/user_ref2_shop.png` — same frame style, МАГАЗИН title, 3×4 grid of shop icons, vanilla player inventory below.

The user also linked 4 packs on black-minecraft.com as visual inspiration (Cloudflare blocked our scraping):
* https://black-minecraft.com/resources/kingdom-hotbar-15-00.4407/ — paid Kingdom Hotbar by 3BSTUDIO, mirror found at https://mcmodels.net/products/8567/kingdom-hotbar (medieval/royal style, $$)
* https://black-minecraft.com/resources/icons-v-1.4899/
* https://black-minecraft.com/resources/icons-v-3.4895/
* https://black-minecraft.com/resources/shopguiplus-ui.5359/

**User constraint:** "не в точь точь нужно всё своё" — don't copy 1:1, design our own in the same ornate style but in `#FF5700` + `#0F0F0F` (no purple, no gold; orange + dark gray + dim highlights only).

Design checklist for the next iteration of `compose_combined()`:
* Decorative outer frame ~3 px thick, orange `#FF5700` core, darker `#A03200` outline on outer edge, brighter `#FF8A40` highlight on inner edge.
* Corner ornaments: small curl/scroll motifs (think Asian/baroque curls), drawn pixel-art style. ~14×14 px each, one per corner.
* Title ribbon at top center: existing banner PNG composited at glyph y=3.
* Slot bevels: 16×16 dark `#181818` interior, 1 px `#080808` top-left shadow + 1 px `#3C3C3C` bottom-right highlight (raised bevel).
* Center panel between frame and slots: solid `#0F0F0F` or `#1C1C1C`.
* Player inventory area (below chest top section): same dark panel + slot grid OR transparent. If transparent, vanilla light-gray inventory shows through (might look ugly). **Recommend filling it too with the same dark theme** since the glyph already extends that far down.
* Optional: small decorative accent lines connecting corners (don't overdo it).

**Width:** start with PNG width 176, ascent=13. If the 8 px right-offset looks ugly, retry with 168.

---

## 9. Color-Mapping Philosophy (for retinting reference packs)

When retinting an existing dark/gray pack (e.g. Dark Mode GUI 1.16.5) to our palette, classify each pixel by brightness `b = (r+g+b)/3`:

```
b < 30   → BLACK       #0F0F0F
b < 50   → DK_PANEL    #1C1C1C
b < 70   → MID_PANEL   #282828
b < 100  → ORANGE_DK   #A03200
b < 150  → ORANGE      #FF5700
b ≥ 150  → ORANGE_HI   #FF8A40
```

This is "harsh" retinting (v2). For a "subtle" retinting (v3) keep slot bevels as neutral grays and only retint the outer frame to orange. See `retint_subtle.py`.

---

## 10. Known Risks / Quirks / Edge Cases

* **Oraxen 1.119.0 on Paper 1.16.5 is unusual.** The user is on a pirate build. Vanilla Oraxen 1.119.x normally requires 1.18+. Stick to features that work with 1.16.5 pack format (`pack_format: 6`).
* **MC 1.16.5 has no `space` font provider.** Negative-width chars / shifts are not possible via Oraxen's "auto-injected space provider" feature. We must accept the 8 px chest title offset.
* **DeluxeMenus YAML strings:** `menu_title` uses `<font:>...</font>` MiniMessage tags. The `\uE001` etc. characters are LITERAL bytes (UTF-8 sequence `EE 80 81` etc.), not escape sequences. When writing YAMLs via API, write the raw UTF-8 bytes — don't write `\u` literally.
* **HTTP 502 on write:** Pterodactyl panel sometimes returns 502 on big writes (>100 KB). Retry once with 500 ms delay. Both retries should succeed.
* **CRC warnings on `pack.zip`:** Oraxen obfuscates the zip. Ignore CRC warnings; contents are valid. Verify by re-fetching from `http://atlas.oraxen.com:8080/pack.zip?id=<HASH>`.
* **`mandatory: true` in settings.yml:** clients are forced to accept the pack. Don't ship a broken pack — players will be disconnected. Always verify locally first via `preview_overlay.py`.
* **`pack_format: 6` is REQUIRED for 1.16.5.** Don't bump it. (`/plugins/Oraxen/pack/pack.mcmeta` should already say `pack_format: 6`.)
* **`menu/masks.yml` and `shop/masks.yml`** use plain text titles, not glyphs. Leave them alone.
* **`menu/akriwer.yml` + `akriwer1.yml` + `akriwer2.yml`** all share U+E00F. If you generate 3 different "akriwer" menus with the same overlay, that's fine — they're variants of the same menu.

---

## 11. Recovery / Emergency Reset

If something breaks badly and players see broken textures / can't connect:

1. **Re-deploy the last known-good pack** (we keep a backup zip at `https://site-asyskpvb.devinapps.com/grief_menu_pack.zip`, SHA1 `30804a2a3bd5f5262c6b5677577746c18b821d53`):
   ```bash
   # Update server.properties resource-pack URL (but Oraxen overrides this — see below)
   # Better: just delete the offending files from /plugins/Oraxen/pack/ and reload.
   ```

2. **Disable Oraxen's pack delivery entirely** (last-resort kill switch — players will get whatever URL is in `server.properties`):
   ```yaml
   # in /plugins/Oraxen/settings.yml
   Pack:
     dispatch:
       send_pack: false
   ```
   Then restart the server (full restart, not just `o reload pack`).

3. **Roll back to vanilla menus (no banners, no overlays)**: edit every `menu_title` line in `/plugins/DeluxeMenus/gui_menus/{menu,shop}/*.yml` to plain text like `'&8&l> &0Меню'`. Then `dm reload`.

---

## 12. Things the User Has Said (load-bearing)

* "В инвентаре не должны быть эти текстуры, только в менюшках. В сундуках тоже не должны." — vanilla chest + player inventory must look vanilla. Only DeluxeMenus menus get themed. → §4 (title-overlay glyph technique).
* "Oraxen по максимуму юзай." — use Oraxen's font/glyph system; don't override generic textures.
* "Сначала прямо сейчас давай исходники" — they want the source bundle right now (this HANDOFF + scripts) before next iteration.
* "Не в точь точь нужно всё своё" — don't copy reference packs 1:1; redesign in our brand.
* Reference screenshots: `refs/user_ref1_menu.png`, `refs/user_ref2_shop.png` (ornate Asian-fantasy frame style with corner curls + small title ribbon).
* Reference forum packs: 4 black-minecraft.com URLs listed in §8 (Cloudflare-protected; user wants those AS INSPIRATION not direct copies).

---

## 13. Quick "Continue from where I left off" Checklist for the next session

1. ☐ Read this whole HANDOFF.
2. ☐ Look at the two reference screenshots in `refs/`.
3. ☐ Rewrite `compose_combined()` in `gen_combined_glyphs.py` to produce an ornate orange-black frame inspired by the references (§8 checklist).
4. ☐ Run `python3 gen_combined_glyphs.py` → check `combined_pack/assets/minecraft/textures/font/menus/*.png`.
5. ☐ Run `python3 preview_overlay.py` → verify the overlay looks centered (or accept 8 px offset).
6. ☐ Run a one-menu deploy first (menu/menu.yml → U+F001) to test before bulk-rolling.
7. ☐ Ask user for in-game screenshot; iterate.
8. ☐ Once approved, bulk-rewrite all 28 YAMLs and reload.
9. ☐ Update this HANDOFF with the final result + screenshot.
