"""
Final version: add slot cells for ALL menu PNGs using char→texture map from default.json
and slot/shift info from each menu YAML in all_dm_menus/.
"""
import os, re, json
import numpy as np
from PIL import Image

DM_DIR  = "/home/ubuntu/menu_work/v8/menu_pack/all_dm_menus"
DEFJSON = "/tmp/pack/assets/minecraft/font/default.json"
SRC_DIR = "/home/ubuntu/menu_work/v8/menu_pack/textures_step3_no_banner"
OUT_DIR = "/home/ubuntu/menu_work/v8/menu_pack/textures_step5_with_cells"
os.makedirs(OUT_DIR, exist_ok=True)

# Char -> texture (and h)
with open(DEFJSON) as f:
    d = json.load(f)
char_to_tex = {}
char_to_h = {}
for p in d['providers']:
    if p.get('type') == 'bitmap' and p.get('height', 0) > 0:
        if 'font/menus' in p.get('file', ''):
            ch = p['chars'][0]
            char_to_tex[ch] = p['file'].replace('font/menus/', '').replace('.png', '')
            char_to_h[ch] = p['height']

# Shift glyphs (effective values, not raw h)
SHIFT_GLYPHS = {
    "\u0BE7": -1, "\u0BE8": -2, "\u0BE9": -4,
    "\u0BEA": -8, "\u0BEB": -16, "\u0BEC": -32,
    "\u0BED": -64, "\u0BEE": -128, "\u0BEF": -256,
}

# For each menu YAML, find which texture it uses + shift + slots
menu_yamls = {}  # texture -> (shift, slots)
for fn in sorted(os.listdir(DM_DIR)):
    if not fn.endswith(".yml"):
        continue
    with open(os.path.join(DM_DIR, fn)) as f:
        content = f.read()
    tm = re.search(r'^menu_title:\s*"?(.+?)"?\s*$', content, re.MULTILINE)
    if not tm:
        continue
    title = tm.group(1)
    # Find texture from title chars
    tex = None
    shift = 0
    for ch in title:
        if ch in char_to_tex:
            tex = char_to_tex[ch]
        elif ch in SHIFT_GLYPHS:
            shift += SHIFT_GLYPHS[ch]
    if not tex:
        print(f'  {fn}: no texture found in title {title!r}')
        continue
    slots = sorted(set(int(m.group(1)) for m in re.finditer(r"^\s*slot:\s*(\d+)", content, re.MULTILINE)))
    if tex in menu_yamls:
        # Merge slots (multiple yamls may share same texture)
        old_shift, old_slots = menu_yamls[tex]
        menu_yamls[tex] = (old_shift, sorted(set(old_slots) | set(slots)))
    else:
        menu_yamls[tex] = (shift, slots)
    print(f'  {fn}: tex={tex}, shift={shift}, slots={slots}')


def cell_for_png(arr, slot, scale, shift_px,
                 fill_strength=0.55, border_strength=0.30):
    row, col = slot // 9, slot % 9
    mc_x = -1 - shift_px + col * 18
    mc_y = 36 + row * 18
    x0 = int(round(mc_x / scale))
    y0 = int(round(mc_y / scale))
    cell_size = int(round(16 / scale))
    x1, y1 = x0 + cell_size, y0 + cell_size
    h, w = arr.shape[:2]
    if x1 > w or y1 > h or x0 < 0 or y0 < 0:
        return
    ix0, iy0 = x0 + 1, y0 + 1
    ix1, iy1 = x1 - 1, y1 - 1
    cell = arr[iy0:iy1, ix0:ix1, :3].astype(float)
    if cell.size == 0:
        return
    avg = cell.mean(axis=(0, 1))
    fill = (avg * fill_strength).clip(0, 255).astype(np.uint8)
    edge = (avg * border_strength).clip(0, 255).astype(np.uint8)
    arr[iy0:iy1, ix0:ix1, :3] = fill
    arr[iy0, ix0:ix1, :3] = edge
    arr[iy1-1, ix0:ix1, :3] = edge
    arr[iy0:iy1, ix0, :3] = edge
    arr[iy0:iy1, ix1-1, :3] = edge


# Process all PNGs
count = 0
for tex_fn in sorted(os.listdir(SRC_DIR)):
    if not tex_fn.endswith(".png"):
        continue
    tex_name = tex_fn[:-4]
    img = Image.open(os.path.join(SRC_DIR, tex_fn)).convert("RGBA")
    arr = np.array(img)
    if tex_name in menu_yamls:
        shift_px, slots = menu_yamls[tex_name]
        # find height from char_to_h via reverse lookup
        h_px = None
        for ch, tn in char_to_tex.items():
            if tn == tex_name:
                h_px = char_to_h[ch]
                break
        if h_px is None:
            h_px = 268
        scale = h_px / 256.0
        for s in slots:
            cell_for_png(arr, s, scale, shift_px)
        print(f'  {tex_fn}: h={h_px} shift={shift_px} slots={slots}')
    Image.fromarray(arr).save(os.path.join(OUT_DIR, tex_fn))
    count += 1

print(f'\nProcessed {count} textures into {OUT_DIR}')
