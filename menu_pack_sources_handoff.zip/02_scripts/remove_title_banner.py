"""
Step 2 of fix: Remove the orange title banner around МЕНЮ-style text.
Replaces banner orange pixels with the brown menu interior color
so the title text floats on the brown background without orange shadow halo.
Keeps outer menu frame, spiral corners, and the white letters intact.
"""
import os, sys
import numpy as np
from PIL import Image

SRC_DIR = "/home/ubuntu/menu_work/v8/menu_pack/textures_step1_no_grid"
OUT_DIR = "/home/ubuntu/menu_work/v8/menu_pack/textures_step3_no_banner"
os.makedirs(OUT_DIR, exist_ok=True)

# Banner region in PNG pixel coords
BANNER_Y0, BANNER_Y1 = 20, 33    # exclusive end
BANNER_X0, BANNER_X1 = 20, 148   # banner spans between spiral corners

# Reference row to sample brown from (well below title)
REF_Y = 50


def is_letter_white(p):
    """White-ish pixels (the title letters МЕНЮ etc)"""
    r, g, b, a = p
    return a > 0 and r > 200 and g > 200 and b > 200


def is_orange(p):
    """Banner orange frame pixels"""
    r, g, b, a = p
    if a == 0:
        return False
    # bright orange
    if r > 200 and g < 100 and b < 80:
        return True
    # light orange
    if r > 220 and 100 <= g <= 170 and b < 100:
        return True
    # dark orange
    if 130 <= r <= 220 and g < 80 and b < 40:
        return True
    return False


def process(src_path, out_path):
    img = Image.open(src_path).convert("RGBA")
    arr = np.array(img)
    h, w = arr.shape[:2]

    # Sample reference brown row at REF_Y
    ref_row = arr[REF_Y, :, :].copy()

    for y in range(BANNER_Y0, BANNER_Y1):
        for x in range(BANNER_X0, BANNER_X1):
            p = arr[y, x]
            if p[3] == 0:
                continue
            if is_letter_white(p):
                continue
            if is_orange(p):
                # Replace with brown sample
                arr[y, x] = ref_row[x]
                # Maintain alpha
                arr[y, x, 3] = 255

    Image.fromarray(arr).save(out_path)


if __name__ == "__main__":
    count = 0
    for fn in sorted(os.listdir(SRC_DIR)):
        if not fn.endswith(".png"):
            continue
        process(os.path.join(SRC_DIR, fn), os.path.join(OUT_DIR, fn))
        count += 1
    print(f"Processed {count} textures into {OUT_DIR}")
