# Menu Customization — что было сделано и как

Этот архив — всё, что я делал с твоими меню (Oraxen GUI overlay + DeluxeMenus). Внутри: оригиналы v7, два промежуточных состояния текстур, скрипты-генераторы, актуальные YAML с сервера и инструкции как всё применить руками если что.

---

## Что вообще происходит технически

Твои меню — это **DeluxeMenus** меню, у которых в `menu_title:` стоит спец-символ из шрифта Oraxen. Этот спец-символ — это PNG-картинка размером 256×256 (texture), которую MC рисует в title-области сундука. PNG большая → визуально перекрывает не только title bar, но и весь chest GUI сверху → выглядит как кастомный интерфейс. Это и есть «orange overlay».

Файлы участвуют 3 категории:

1. **PNG текстуры** в `/plugins/Oraxen/pack/textures/font/menus/*.png` — сами картинки оверлеев.
2. **Glyph YAML** `/plugins/Oraxen/glyphs/menus_overlay.yml` — для каждой текстуры задаёт `texture`, `char` (какой unicode-символ её триггерит), `ascent` (вертикальная привязка), `height` (масштаб в GUI пикселях).
3. **DM меню YAML** `/plugins/DeluxeMenus/gui_menus/menu/*.yml` и `gui_menus/shop/*.yml` — содержат `menu_title: "&f<shift><glyph>"` где shift — невидимый «сдвиг курсора влево» (нужно чтобы оверлей покрыл chest GUI а не начинался от title bar).

---

## Что было плохо в v7

1. **Серая сетка 9×6 «взади»** — на всех 28 текстурах в фоне была впечатанная решётка из тёмно-серых пикселей (RGB ~60,60,60) — формировала визуальный grid пустых слотов.
2. **`/menu` открывал «Default Menu»** — DM-шаблонные `panel.yml` и `donatePVEOTHER.yml` имели `open_command: menu` и битый контент (dirt/grass/...). Они конфликтовали с настоящим `menu.yml`.
3. **Шрифтовый шифт не работал правильно** — в shift-кодпойнтах были combining marks, MC рендерил их как символы а не как сдвиги. Поэтому оверлей не вставал по центру chest GUI.

В прошлой сессии (до меня) пункты 2 и 3 уже разобрали и пофиксили, мне на этой сессии пришёл пункт 1 + допиливание.

---

## Что я сделал

### Шаг 1: Убрать сетку (`scripts/inpaint_grid.py`)

Берём каждую v7 текстуру, маскируем **только** серые grid-пиксели (RGB 45..75, balanced channels — т.е. R≈G≈B), для каждого подбираем усреднённый цвет из 4 ближайших не-серых соседей в радиусе 7 px. Заменяется ТОЛЬКО grid; frame (bright orange 160,50,0), title (white 255,255,255), декоративные элементы — не попадают в маску по определению, потому что они не серые.

Результат → `textures_step1_no_grid/`.

Запуск:

```bash
python3 scripts/inpaint_grid.py
```

(внутри захардкожены пути `/home/ubuntu/repos/tgbot/...` — если будешь запускать у себя, поправь IN_DIR/OUT_DIR в начале файла).

### Шаг 2: Добавить ячейки под предметы (`scripts/add_slot_cells.py`)

Скрипт читает каждый DeluxeMenus YAML, вытаскивает слоты предметов (по `slot: N`), и для каждого слота рисует в соответствующей PNG-текстуре тёмную ячейку 14×14 px:

- Внутренняя заливка: цвет фона × 0.55 (тёмная)
- 1px рамка: цвет фона × 0.30 (ещё темнее)
- Без highlight'ов → плоский inset-look а не выпуклая кнопка

Координаты ячейки в PNG (для слота N в 9×6 grid):

```
col = N % 9
row = N // 9
x = col*18
y = 18 + row*18     # +18 потому что сверху title ribbon
```

Размер cell в PNG = 18×18, рисуем во внутренних 14×14 (отступ 2 px со всех сторон).

Результат → `textures_step2_with_cells/`.

```bash
python3 scripts/add_slot_cells.py
```

(тоже нужно поправить пути в начале если запускаешь у себя).

### Шаг 3: Скорректировать YAML-ы

В `current_server_state/dm_menus/menu.yml`:

```yaml
menu_title: "&f௫ோ"
```

- `&f` — белый цвет (формальность; цвет берётся из самой PNG)
- `௫` (U+0BEB) — шифт-глиф высотой -18 px (двигает курсор влево на ~18 px)
- `ோ` (U+0BCB) — глиф нашей menu.png (Oraxen перевешивает его на U+F001 → но в default.json он соапится с тамильским кодпойнтом)

В `current_server_state/glyphs/menus_overlay.yml` для menu увеличена `height: 260 → 280` (растягивает текстуру вниз чтобы покрыть нижний ряд слотов 48-50).

В `panel.yml` и `donatePVEOTHER.yml` — восстановлены из legacy `/plugins/DeluxeMenus/menu/panel.yml` и `/plugins/DeluxeMenus/shop/donatePVEOTHER.yml`. Это убрало «Default Menu» с дёртом который перехватывал `/menu`.

### Что НЕ сделано

- **Шрифтовая тень «МЕНЮ»**. В 1.16.5 MC всегда рендерит шрифт с тенью 1px вправо-вниз, color = main_color × 0.25. Поскольку всё «МЕНЮ» — это пиксели в PNG, тень рисует всю PNG со сдвигом → выглядит как оранжевый смаз за буквами. Чтобы убрать — нужно либо:
  1. Вынести текст «МЕНЮ» из PNG, оставить только оранжевый бокс и пустой ribbon. Рендерить «МЕНЮ» отдельной командой (стандартный MC текст с обычной маленькой тенью). Нужно переделывать все 28 PNG + все menu_title с дополнительным шифтом.
  2. Использовать NMS hack чтобы выключить тень в title rendering. Требует своего плагина или ServerMenu плагина с поддержкой `shadow: false`.
  3. Обновить сервер на 1.20+ где поддерживается `shadow: false` в bitmap font provider.

  Если решишь делать — скажи, переделаю.

---

## Как задеплоить руками (если что-то сломалось)

Залить файлы можно через панель `https://mgr.hosting-minecraft.pro` файловый менеджер, или через API:

```bash
KEY="ptlc_q1LTOfeHyId0pGueJl1WQMYKfK6nqXngMuqcgKRgbQd"
BASE="https://mgr.hosting-minecraft.pro/api/client/servers/944c2567"

# 1. Текстуры
for f in textures_step2_with_cells/*.png; do
  fname=$(basename "$f")
  ENC=$(python3 -c "import urllib.parse;print(urllib.parse.quote('/plugins/Oraxen/pack/textures/font/menus/'+'$fname'))")
  curl -sf -X POST -H "Authorization: Bearer $KEY" \
    -H "Content-Type: application/octet-stream" \
    --data-binary "@$f" "$BASE/files/write?file=$ENC"
done

# 2. Glyph YAML
curl -sf -X POST -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/octet-stream" \
  --data-binary "@current_server_state/glyphs/menus_overlay.yml" \
  "$BASE/files/write?file=$(python3 -c "import urllib.parse;print(urllib.parse.quote('/plugins/Oraxen/glyphs/menus_overlay.yml'))")"

# 3. DM YAMLs
for f in current_server_state/dm_menus/*.yml; do
  fname=$(basename "$f")
  # menu.yml и panel.yml идут в menu/, остальные donate* в shop/
  case "$fname" in
    menu.yml|panel.yml) target="menu" ;;
    *) target="shop" ;;
  esac
  ENC=$(python3 -c "import urllib.parse;print(urllib.parse.quote('/plugins/DeluxeMenus/gui_menus/'+'$target/$fname'))")
  curl -sf -X POST -H "Authorization: Bearer $KEY" \
    -H "Content-Type: application/octet-stream" \
    --data-binary "@$f" "$BASE/files/write?file=$ENC"
done

# 4. Перезагрузить
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"oraxen reload all"}' "$BASE/command"
sleep 8
curl -s -X POST -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"command":"dm reload"}' "$BASE/command"

# 5. В игре F3+T чтобы перекачать ресурспак
```

---

## Структура архива

```
menu_pack/
├── README.md                          ← этот файл
├── scripts/
│   ├── inpaint_grid.py                ← убирает серую сетку из v7
│   └── add_slot_cells.py              ← добавляет тёмные ячейки под предметы
├── textures_v7_original/              ← оригинальные v7 (28 PNG, С сеткой)
├── textures_step1_no_grid/            ← после inpaint_grid.py (без сетки)
├── textures_step2_with_cells/         ← после add_slot_cells.py (с ячейками)
│                                        ← ЭТО ТО ЧТО СЕЙЧАС НА СЕРВЕРЕ
├── yaml_v7_originals/                 ← оригинальные DM YAML из patched_menus
│   ├── menu/                          ← menu.yml, panel.yml и др.
│   └── shop/                          ← donateXxx.yml
└── current_server_state/              ← снимок с сервера ПРЯМО СЕЙЧАС
    ├── dm_menus/                      ← все актуальные DM меню
    ├── glyphs/menus_overlay.yml       ← актуальный glyph config
    └── textures/                      ← актуальные текстуры (= step2_with_cells)
```

---

## Shift-кодпойнты (для справки)

В `default.json` определены отрицательные глифы для сдвига курсора:

| Char | U+ | Height | Эффект |
|---|---|---|---|
| ௧ | 0BE7 | -3 | -1 px |
| ௨ | 0BE8 | -4 | -2 px |
| ௩ | 0BE9 | -6 | -4 px |
| ௪ | 0BEA | -10 | -8 px |
| ௫ | 0BEB | -18 | -16 px ← сейчас у menu |
| ௬ | 0BEC | -34 | -32 px |
| ௭ | 0BED | -66 | -64 px |
| ௮ | 0BEE | -130 | -128 px |
| ௯ | 0BEF | -258 | -256 px |

Если меню нужно сдвинуть больше левее — увеличь шифт (например ௬ или ௭ для menu_title).

---

## Адаптация под другие меню (если будешь добавлять новые)

1. Нарисуй новую PNG (256×256, content в области x=0..167, y=18..142, прозрачное всё остальное)
2. Положи в `/plugins/Oraxen/pack/textures/font/menus/newmenu.png`
3. Добавь в `glyphs/menus_overlay.yml`:
   ```yaml
   menu_overlay_newmenu:
     texture: font/menus/newmenu
     ascent: 32
     height: 268
     char: "\uF01D"  ← следующий свободный код
   ```
4. В `gui_menus/menu/newmenu.yml` пропиши `menu_title: "&f௫<глиф_который_оракстен_подсунет>"`. Чтобы узнать какой кодпойнт Oraxen реально присвоил — после `oraxen reload all` глянь `assets/minecraft/font/default.json` в свежем паке.
5. `oraxen reload all` + `dm reload`.

Если хочешь чтобы у этого нового меню тоже были тёмные ячейки под предметами:

- Создай YAML с items и `slot: N` для каждого предмета
- Запусти `python3 scripts/add_slot_cells.py` (или скопируй логику для одного файла)

---

## Что ещё хорошо бы сделать на будущее

- **Pack format в `pack.mcmeta`**: сейчас стоит 6 (правильно для 1.16.5). Если будешь обновлять сервер — поменяй на нужный (7 для 1.17, 8 для 1.18, 9 для 1.19, 15 для 1.20.1 и т.д.).
- **Title shadow fix** (если решишь делать) — отдельная задача, описана в «Что НЕ сделано» выше.
- **Авто-провека дубликатов open_command** — после деплоя любых новых DM меню запускай `dm reload` и грепи лог `[DeluxeMenus] command:` на варнинги о конфликтах команд.

---

## Контакт

Этот пак собран в сессии Devin https://app.devin.ai/sessions/9039b0e072264a6b9979dadd457cd647 — если что не работает, заходи туда же или напиши новую сессию.
