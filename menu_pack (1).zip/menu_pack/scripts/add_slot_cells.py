"""
Take inpainted v7 textures and add subtle dark slot cells ONLY at item positions
(read from each menu YAML). Match v7's dark cell shade for visual consistency.

Cell layout in PNG:
  - Slot grid: x = col*18..col*18+17, y = 18 + row*18 .. 18 + row*18 + 17
  - 9 cols, 6 rows
  - Top frame/title at y=0..17
  - Bottom frame at y=126..142
"""
import os, re, glob
import numpy as np
from PIL import Image

INPAINT_DIR = "/home/ubuntu/repos/tgbot/deploy_v8_clean/textures_inpaint"
OUT_DIR = "/home/ubuntu/repos/tgbot/deploy_v8_clean/textures_v2"
DM_DIR = "/home/ubuntu/repos/tgbot/deploy_v7_final/patched_menus"

os.makedirs(OUT_DIR, exist_ok=True)

# Read slot positions per menu name
slots_per_menu = {}
for yml in glob.glob(DM_DIR + "/**/*.yml", recursive=True):
    name = os.path.basename(yml).replace(".yml", "")
    slots = set()
    with open(yml) as f:
        content = f.read()
    for m in re.finditer(r"^\s*slot:\s*(\d+)\s*$", content, re.MULTILINE):
        slots.add(int(m.group(1)))
    if slots:
        slots_per_menu[name] = sorted(slots)

# Map YAML name → texture filename
# YAML name -> texture name (the YAML name often has prefix like donateXXX, texture is just xxx.png)
NAME_TO_TEXTURE = {
    "menu": "menu",
    "donate": "donate",
    "donateSHOP": "shop",
    "events": "events",
    "freek": "freek",
    "obmen": "obmen",
    "portals": "portals",
    "help": "help",
    "rtp": "rtp",
    "arenda": "arenda",
    "grab": "grab",
    "media": "media",
    "egorchik": "egorchik",
    "akriwer2": "akriwer",
    "donatePRED": "pred",
    "donatePVE": "pve",
    "donatePVEOTHER": "pveother",
    "donateRESMENU": "resmenu",
    "donateRESEURO": "reseuro",
    "donateRESMONETA": "resmoneta",
    "donateSHARI": "shari",
    "donateSPAWNERS": "spawners",
    "donateARROW": "arrow",
    "donateEGG": "egg",
    "donateITEMS2": "items",
    "donateLIVALKA": "livalka",
    "donatePOTIONS": "potions",
}


def cell_for_png(arr, slot, fill_strength=0.55, border_strength=0.30):
    """
    Draw a subtle dark cell at given slot in PNG arr (inset slot look).
    Slot grid: 9 cols × 6 rows.
    Cell PNG pos: (col*18, 18 + row*18) -- 18x18 cell, drawing in inner 14x14.
    fill_strength: 0.5 = 50% of BG brightness (subtle dark cell)
    border_strength: 0.3 = even darker 1px border
    """
    row = slot // 9
    col = slot % 9
    x0 = col * 18
    y0 = 18 + row * 18
    x1 = x0 + 18
    y1 = y0 + 18

    if x1 > arr.shape[1] or y1 > arr.shape[0]:
        return

    # Inner 14x14 area
    ix0, iy0 = x0 + 2, y0 + 2
    ix1, iy1 = x0 + 16, y0 + 16

    cell = arr[iy0:iy1, ix0:ix1, :3].astype(float)
    avg = cell.mean(axis=(0, 1))
    fill = (avg * fill_strength).clip(0, 255).astype(np.uint8)
    edge = (avg * border_strength).clip(0, 255).astype(np.uint8)

    # Fill inner area with subtle dark (flat, no highlight = clean inset look)
    arr[iy0:iy1, ix0:ix1, 0] = fill[0]
    arr[iy0:iy1, ix0:ix1, 1] = fill[1]
    arr[iy0:iy1, ix0:ix1, 2] = fill[2]

    # 1px darker border on inner perimeter (gives the "inset" outline)
    arr[iy0, ix0:ix1, 0] = edge[0]; arr[iy0, ix0:ix1, 1] = edge[1]; arr[iy0, ix0:ix1, 2] = edge[2]
    arr[iy1 - 1, ix0:ix1, 0] = edge[0]; arr[iy1 - 1, ix0:ix1, 1] = edge[1]; arr[iy1 - 1, ix0:ix1, 2] = edge[2]
    arr[iy0:iy1, ix0, 0] = edge[0]; arr[iy0:iy1, ix0, 1] = edge[1]; arr[iy0:iy1, ix0, 2] = edge[2]
    arr[iy0:iy1, ix1 - 1, 0] = edge[0]; arr[iy0:iy1, ix1 - 1, 1] = edge[1]; arr[iy0:iy1, ix1 - 1, 2] = edge[2]


# Process: for each texture, find its YAML and add cells
processed = 0
for tex_name, yaml_name in [(v, k) for k, v in NAME_TO_TEXTURE.items()]:
    pass

# Build reverse map: yaml -> texture
TEXTURE_TO_YAMLS = {}
for yaml_name, tex in NAME_TO_TEXTURE.items():
    TEXTURE_TO_YAMLS.setdefault(tex, []).append(yaml_name)

# For each texture, find its yaml's slots
for tex_filename in sorted(os.listdir(INPAINT_DIR)):
    if not tex_filename.endswith(".png"):
        continue
    tex_name = tex_filename[:-4]
    yamls = TEXTURE_TO_YAMLS.get(tex_name, [])
    slots = []
    for ym in yamls:
        slots.extend(slots_per_menu.get(ym, []))
    slots = sorted(set(slots))

    img = Image.open(os.path.join(INPAINT_DIR, tex_filename)).convert("RGBA")
    arr = np.array(img)

    if slots:
        for s in slots:
            cell_for_png(arr, s)

    Image.fromarray(arr).save(os.path.join(OUT_DIR, tex_filename))
    print(f"  {tex_filename}: yamls={yamls} slots={slots}")
    processed += 1

print(f"\nProcessed {processed} textures into {OUT_DIR}")

