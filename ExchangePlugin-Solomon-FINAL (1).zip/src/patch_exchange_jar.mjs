#!/usr/bin/env node
/**
 * patch_exchange_jar.mjs  — v2
 *
 * Patches ExchangePlugin-2.0.0.jar:
 *  1. Replaces hardcoded inventory title strings with Solomon glyph titles.
 *  2. Updates MenuClickListener comparison strings to match the new titles
 *     so that click-cancellation and navigation continue to work.
 *
 * New title format (in every patched CONSTANT_Utf8 entry):
 *   §f (3 bytes) + ௭ U+0BED (3 bytes) + \uF0xx (3 bytes) + §0 (2 bytes) + N×SPACE
 *   Total bytes == original bytes (in-place replacement, no class-layout changes).
 *
 * §f  – reset color to white so the glyph renders without colour shift
 * ௭   – Tamil negative-advance shift char already in the server font
 * \uF0xx – Solomon menu glyph (Oraxen menus_overlay.yml char)
 * §0  – black colour so trailing padding spaces are invisible
 */

import fs from 'fs';
import zlib from 'zlib';

const INPUT_JAR  = process.argv[2] ?? 'attached_assets/ExchangePlugin-2.0.0_1779575592395.jar';
const OUTPUT_JAR = process.argv[3] ?? 'attached_assets/ExchangePlugin-2.0.0-solomon.jar';

// ── Glyph codepoints ────────────────────────────────────────────────────────
const G_BIRJA  = '\uF020'; // MainMenuGui   — БИРЖА      (6 rows)
const G_ZAKAZY = '\uF021'; // BrowseGui     — ЗАКАЗЫ     (6 rows)
const G_MOI    = '\uF022'; // MyOrdersGui   — МОИ ЗАКАЗЫ (5 rows)
const G_TIP    = '\uF023'; // CreateOrderGui— all 4 sub-menus (3 rows each)
const G_KOLVO  = '\uF024'; // QuantityGui   — КОЛИЧЕСТВО (3 rows)

// Prefix bytes:  §f (colour reset → white) + ௭ (shift/centre) + glyph char
const PREFIX = '§f\u0BED'; // 6 bytes; append glyph char (3 bytes) → 9 bytes total

/**
 * Per-file patch list.
 * oldStr   – exact constant pool string (JS)
 * newGlyph – Solomon glyph char for this menu
 *
 * MenuClickListener patches MUST mirror the GUI patches exactly so that
 * isPluginMenu(title) still recognises the patched inventory titles.
 */
const PATCHES = {
  // ── GUI classes ─────────────────────────────────────────────────────────
  'MainMenuGui.class': [
    { oldStr: '§0§l⚖ §6§lБИРЖА §0§l⚖',                       newGlyph: G_BIRJA  },
  ],
  'BrowseGui.class': [
    { oldStr: '§0§l☰ §6§lЗАКАЗЫ',                              newGlyph: G_ZAKAZY },
    { oldStr: '§0§l☰ §6§lЗАКАЗЫ\u0001 §7[\u0001/\u0001]',     newGlyph: G_ZAKAZY },
  ],
  'MyOrdersGui.class': [
    { oldStr: '§0§l◎ §f§lМОИ ЗАКАЗЫ',                          newGlyph: G_MOI    },
    { oldStr: '§0§l◎ §f§lМОИ ЗАКАЗЫ §7[\u0001/\u0001]',        newGlyph: G_MOI    },
  ],
  'CreateOrderGui.class': [
    { oldStr: '§0§l✎ §e§lВЫБЕРИТЕ ТИП',                      newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lКУПИТЬ ИЛИ ПРОДАТЬ?',               newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lВАЛЮТА ОПЛАТЫ',                     newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lПОДТВЕРЖДЕНИЕ',                     newGlyph: G_TIP    },
  ],
  'QuantityGui.class': [
    { oldStr: '§0§l✎ §e§lКОЛ-ВО КЕЙСОВ',                     newGlyph: G_KOLVO  },
  ],

  // ── MenuClickListener — isPluginMenu() comparison strings ────────────────
  // Must be identical to the patched GUI titles (same byte count, same content)
  // so that title.equals(…) and title.startsWith(…) keep working.
  'MenuClickListener.class': [
    { oldStr: '§0§l⚖ §6§lБИРЖА §0§l⚖',                       newGlyph: G_BIRJA  },
    { oldStr: '§0§l☰ §6§lЗАКАЗЫ',                              newGlyph: G_ZAKAZY },
    { oldStr: '§0§l◎ §f§lМОИ ЗАКАЗЫ',                          newGlyph: G_MOI    },
    { oldStr: '§0§l✎ §e§lВЫБЕРИТЕ ТИП',                      newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lКУПИТЬ ИЛИ ПРОДАТЬ?',               newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lВАЛЮТА ОПЛАТЫ',                     newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lПОДТВЕРЖДЕНИЕ',                     newGlyph: G_TIP    },
    { oldStr: '§0§l✎ §e§lКОЛ-ВО КЕЙСОВ',                     newGlyph: G_KOLVO  },
  ],
};

// ── Java modified-UTF-8 encoder ─────────────────────────────────────────────
function toJavaUtf8(str) {
  const out = [];
  for (let i = 0; i < str.length; i++) {
    const cp = str.charCodeAt(i);
    if (cp === 0x0000)       { out.push(0xC0, 0x80); }
    else if (cp <= 0x007F)   { out.push(cp); }
    else if (cp <= 0x07FF)   { out.push(0xC0 | (cp >> 6), 0x80 | (cp & 0x3F)); }
    else                     { out.push(0xE0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3F), 0x80 | (cp & 0x3F)); }
  }
  return Buffer.from(out);
}

/** CONSTANT_Utf8 tag+length+payload pattern to search for */
function utf8Pattern(str) {
  const payload = toJavaUtf8(str);
  const hdr     = Buffer.from([0x01, (payload.length >> 8) & 0xFF, payload.length & 0xFF]);
  return Buffer.concat([hdr, payload]);
}

/**
 * Build replacement bytes for a CONSTANT_Utf8 entry.
 *
 * Layout:
 *   tag(1) + len_hi(1) + len_lo(1)
 *   + §f(3) + ௭(3) + glyph(3)      ← 9-byte visible prefix
 *   + §0(2) + spaces(N)             ← invisible padding
 *   + \u0001 × K                    ← StringConcatFactory placeholders (1 byte each)
 *
 * Total payload bytes == original payload bytes (in-place replacement).
 *
 * CRITICAL: paginated title strings contain \u0001 chars that serve as
 * argument slots for StringConcatFactory.makeConcatWithConstants().
 * If the replacement has a different \u0001 count the JVM throws
 * BootstrapMethodError at class-load time. We preserve the count and
 * append all \u0001 chars AFTER §0+spaces so the inserted page numbers
 * render in §0 (black) and are invisible on the chest title bar.
 */
function buildReplacement(oldStr, glyphChar) {
  const origPayloadLen = toJavaUtf8(oldStr).length;
  const prefixBytes    = toJavaUtf8(PREFIX + glyphChar); // §f + ௭ + glyph = 9 bytes
  const sectionZero    = toJavaUtf8('§0');               // 2 bytes

  // Count how many \u0001 placeholders are in the original string.
  // Each \u0001 (U+0001) is 1 byte in Java modified-UTF-8.
  const placeholderCount = (oldStr.match(/\u0001/g) || []).length;
  const placeholderBytes = placeholderCount; // 1 byte each

  const spaceCount = origPayloadLen
    - prefixBytes.length
    - sectionZero.length
    - placeholderBytes;

  if (spaceCount < 0) {
    throw new Error(
      `Cannot pad "${oldStr.slice(0,30)}" — prefix too long! ` +
      `need ${origPayloadLen} bytes, used ${prefixBytes.length + sectionZero.length + placeholderBytes}`
    );
  }

  // \u0001 in Java modified-UTF-8 is 0x01 (single byte, non-null range)
  const placeholders = Buffer.alloc(placeholderCount, 0x01);

  const newPayload = Buffer.concat([
    prefixBytes,
    sectionZero,
    Buffer.alloc(spaceCount, 0x20), // ASCII spaces
    placeholders,                    // \u0001 … at the end, rendered §0 (invisible)
  ]);

  if (newPayload.length !== origPayloadLen) {
    throw new Error(
      `BUG: payload length mismatch for "${oldStr.slice(0,30)}": ` +
      `got ${newPayload.length}, expected ${origPayloadLen}`
    );
  }

  const hdr = Buffer.from([0x01, (origPayloadLen >> 8) & 0xFF, origPayloadLen & 0xFF]);
  return Buffer.concat([hdr, newPayload]);
}

/** Replace ALL non-overlapping occurrences of needle with replacement (same length). */
function replaceAll(buf, needle, replacement) {
  let hits = 0, pos = 0;
  while (true) {
    const idx = buf.indexOf(needle, pos);
    if (idx === -1) break;
    replacement.copy(buf, idx);
    pos = idx + needle.length;
    hits++;
  }
  return hits;
}

// ── ZIP/JAR helpers ─────────────────────────────────────────────────────────
function findEocd(buf) {
  for (let i = buf.length - 22; i >= 0; i--)
    if (buf[i]===0x50&&buf[i+1]===0x4B&&buf[i+2]===0x05&&buf[i+3]===0x06) return i;
  throw new Error('EOCD not found');
}

function parseCentralDir(buf) {
  const eocd    = findEocd(buf);
  const cdOff   = buf.readUInt32LE(eocd + 16);
  const cdCount = buf.readUInt16LE(eocd + 8);
  const entries = new Map();
  let p = cdOff;
  for (let i = 0; i < cdCount; i++) {
    const method   = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const uncompSz = buf.readUInt32LE(p + 24);
    const fnLen    = buf.readUInt16LE(p + 28);
    const exLen    = buf.readUInt16LE(p + 30);
    const cmtLen   = buf.readUInt16LE(p + 32);
    const localOff = buf.readUInt32LE(p + 42);
    const name     = buf.slice(p+46, p+46+fnLen).toString('utf8');
    entries.set(name, { method, compSize, uncompSz, localOff });
    p += 46 + fnLen + exLen + cmtLen;
  }
  return entries;
}

function readClassBytes(jar, info) {
  const { method, compSize, localOff } = info;
  const fnLen  = jar.readUInt16LE(localOff + 26);
  const exLen  = jar.readUInt16LE(localOff + 28);
  const dataOff = localOff + 30 + fnLen + exLen;
  const raw    = jar.slice(dataOff, dataOff + compSize);
  return { dataOff, raw, classBytes: method === 8 ? zlib.inflateRawSync(raw) : Buffer.from(raw) };
}

// ── CRC-32 ──────────────────────────────────────────────────────────────────
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t[i]=c;}
  return t;
})();
function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i=0;i<buf.length;i++) c=(c>>>8)^CRC_TABLE[(c^buf[i])&0xFF];
  return (c^0xFFFFFFFF)>>>0;
}

// ── Main ────────────────────────────────────────────────────────────────────
const jar = fs.readFileSync(INPUT_JAR);
console.log(`JAR loaded: ${INPUT_JAR}  (${jar.length} bytes)`);

const central = parseCentralDir(jar);
console.log(`Central directory: ${central.size} entries\n`);

// Collect patched class data keyed by entry name
const patchedClasses = new Map();
let totalPatches = 0;

for (const [targetBase, patchList] of Object.entries(PATCHES)) {
  // Find entry (class files are inside package directories)
  let entryName = null;
  for (const name of central.keys())
    if (name === targetBase || name.endsWith('/' + targetBase)) { entryName = name; break; }

  if (!entryName) { console.warn(`⚠  ${targetBase} not found in JAR`); continue; }

  const info = central.get(entryName);
  const { classBytes } = readClassBytes(jar, info);

  console.log(`Patching ${entryName}  (${classBytes.length} bytes)`);
  let classTouched = 0;

  for (const { oldStr, newGlyph } of patchList) {
    const needle      = utf8Pattern(oldStr);
    const replacement = buildReplacement(oldStr, newGlyph);
    if (needle.length !== replacement.length) throw new Error('BUG: length mismatch!');

    const count = replaceAll(classBytes, needle, replacement);
    if (count === 0) {
      console.warn(`  ⚠  Not found: "${oldStr.slice(0,40)}"`);
    } else {
      const cpHex = newGlyph.charCodeAt(0).toString(16).toUpperCase().padStart(4,'0');
      console.log(`  ✓  ×${count}  "${oldStr.slice(0,35)}…" → \\uF${cpHex.slice(1)}`);
      classTouched += count;
      totalPatches += count;
    }
  }

  if (classTouched > 0) {
    patchedClasses.set(entryName, {
      classBytes,
      newCompressed: zlib.deflateRawSync(classBytes, { level: 6 }),
    });
  }
  console.log('');
}

// ── Rebuild JAR ──────────────────────────────────────────────────────────────
console.log('Rebuilding JAR…');

const eocdOff  = findEocd(jar);
const cdOff    = jar.readUInt32LE(eocdOff + 16);
const cdCount  = jar.readUInt16LE(eocdOff + 8);

const localParts = [];
const outBufs    = [];
let cursor = 0;

let p = cdOff;
for (let i = 0; i < cdCount; i++) {
  const method   = jar.readUInt16LE(p + 10);
  const crcOld   = jar.readUInt32LE(p + 16);
  const compSzOld= jar.readUInt32LE(p + 20);
  const uncompSz = jar.readUInt32LE(p + 24);
  const fnLen    = jar.readUInt16LE(p + 28);
  const exLen    = jar.readUInt16LE(p + 30);
  const cmtLen   = jar.readUInt16LE(p + 32);
  const localOff = jar.readUInt32LE(p + 42);
  const name     = jar.slice(p+46, p+46+fnLen).toString('utf8');

  const lfnLen   = jar.readUInt16LE(localOff + 26);
  const lexLen   = jar.readUInt16LE(localOff + 28);
  const dataOff  = localOff + 30 + lfnLen + lexLen;
  const localEx  = jar.slice(localOff + 30 + lfnLen, localOff + 30 + lfnLen + lexLen);

  let compData, finalUncomp, finalCrc;

  if (patchedClasses.has(name)) {
    const pc   = patchedClasses.get(name);
    compData   = pc.newCompressed;
    finalUncomp= pc.classBytes.length;
    finalCrc   = crc32(pc.classBytes);
  } else {
    compData   = jar.slice(dataOff, dataOff + compSzOld);
    finalUncomp= uncompSz;
    finalCrc   = crcOld;
  }

  const nameB = Buffer.from(name, 'utf8');
  const lhdr  = Buffer.alloc(30);
  lhdr.writeUInt32LE(0x04034B50, 0);
  lhdr.writeUInt16LE(20,           4);
  lhdr.writeUInt16LE(0,            6);
  lhdr.writeUInt16LE(method,       8);
  lhdr.writeUInt16LE(0,           10);
  lhdr.writeUInt16LE(0,           12);
  lhdr.writeUInt32LE(finalCrc,    14);
  lhdr.writeUInt32LE(compData.length, 18);
  lhdr.writeUInt32LE(finalUncomp, 22);
  lhdr.writeUInt16LE(nameB.length,26);
  lhdr.writeUInt16LE(localEx.length, 28);

  localParts.push({ name, nameB, method, crc: finalCrc,
                    compLen: compData.length, uncompLen: finalUncomp, localOff: cursor });
  outBufs.push(lhdr, nameB, localEx, compData);
  cursor += 30 + nameB.length + localEx.length + compData.length;

  p += 46 + fnLen + exLen + cmtLen;
}

// Central directory
const cdBufs  = [];
const cdStart = cursor;
for (const lp of localParts) {
  const cd = Buffer.alloc(46);
  cd.writeUInt32LE(0x02014B50, 0);
  cd.writeUInt16LE(20,          4);
  cd.writeUInt16LE(20,          6);
  cd.writeUInt16LE(0,           8);
  cd.writeUInt16LE(lp.method,  10);
  cd.writeUInt16LE(0,          12);
  cd.writeUInt16LE(0,          14);
  cd.writeUInt32LE(lp.crc,    16);
  cd.writeUInt32LE(lp.compLen, 20);
  cd.writeUInt32LE(lp.uncompLen, 24);
  cd.writeUInt16LE(lp.nameB.length, 28);
  cd.writeUInt16LE(0,          30);
  cd.writeUInt16LE(0,          32);
  cd.writeUInt16LE(0,          34);
  cd.writeUInt16LE(0,          36);
  cd.writeUInt32LE(0,          38);
  cd.writeUInt32LE(lp.localOff,42);
  cdBufs.push(cd, lp.nameB);
  cursor += 46 + lp.nameB.length;
}

const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054B50,  0);
eocd.writeUInt16LE(0,            4);
eocd.writeUInt16LE(0,            6);
eocd.writeUInt16LE(localParts.length,  8);
eocd.writeUInt16LE(localParts.length, 10);
eocd.writeUInt32LE(cursor - cdStart, 12);
eocd.writeUInt32LE(cdStart,         16);
eocd.writeUInt16LE(0,              20);

const finalJar = Buffer.concat([...outBufs, ...cdBufs, eocd]);
fs.writeFileSync(OUTPUT_JAR, finalJar);

console.log(`\nOutput: ${OUTPUT_JAR}  (${finalJar.length} bytes)`);
console.log(`Total replacements: ${totalPatches}`);
if (totalPatches === 0) { console.error('✗ Nothing patched!'); process.exit(1); }
else console.log('✓ Done.');
