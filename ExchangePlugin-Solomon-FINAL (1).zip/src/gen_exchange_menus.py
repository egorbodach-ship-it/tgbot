#!/usr/bin/env python3
"""
Generate Solomon-style PNG textures for ExchangePlugin menus.
Uses gen_solomon_v5.render_menu_glyph and render_preview directly.
"""
import sys, os

GEN_DIR = os.path.join(os.path.dirname(__file__), '..', 'attached_assets', 'solomon_generator')
sys.path.insert(0, GEN_DIR)

import gen_solomon_v5 as gen

EXCHANGE_MENUS = [
    # (name,               label,            rows)
    ("exchange_birja",     "БИРЖА",          6),   # MainMenuGui    \uF020
    ("exchange_zakazy",    "ЗАКАЗЫ",         6),   # BrowseGui      \uF021
    ("exchange_moi",       "МОИ ЗАКАЗЫ",     5),   # MyOrdersGui    \uF022
    ("exchange_tip",       "ТИП ТОВАРА",     3),   # CreateOrderGui \uF023
    ("exchange_kolvo",     "КОЛИЧЕСТВО",     3),   # QuantityGui    \uF024
]

out_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(__file__), '..', 'attached_assets', 'exchange_pack_output')
prev_dir = os.path.join(out_dir, 'preview')
os.makedirs(out_dir, exist_ok=True)
os.makedirs(prev_dir, exist_ok=True)

CODEPOINTS = ["\uF020", "\uF021", "\uF022", "\uF023", "\uF024"]

for (name, label, rows), cp in zip(EXCHANGE_MENUS, CODEPOINTS):
    glyph = gen.render_menu_glyph(name, label, rows)
    out_path = os.path.join(out_dir, name + '.png')
    glyph.save(out_path)
    print(f"  wrote {out_path}")

    try:
        prev = gen.render_preview(name, label, rows, glyph)
        prev.save(os.path.join(prev_dir, 'solomon_' + name + '.png'))
        print(f"        preview → {os.path.join(prev_dir, 'solomon_' + name + '.png')}")
    except Exception as e:
        print(f"  (preview skipped: {e})")

print(f"\nDone: 5 exchange textures → {out_dir}")
print("\nCodepoints:")
for (name, label, rows), cp in zip(EXCHANGE_MENUS, CODEPOINTS):
    cp_hex = hex(ord(cp))
    print(f"  {cp_hex} ({cp}) = {name}.png  ({label}, {rows} rows)")
